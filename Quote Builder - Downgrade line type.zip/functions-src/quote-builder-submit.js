'use strict';
// Rebuilds the quote from fresh catalog data (never trusts client prices), then writes:
//   1. line items on the deal (primary option only)   2. a separate copy of each on the quote
//   3. the quote (template, contact, deal, builder state)   4. the printed deal properties
//   5. for the primary option, archives line items an earlier builder run left on the deal
// A deal can hold several builder quotes ("options", e.g. 100 vs 250 agents). Only the
// primary option's lines sit on the deal, so the deal amount reflects one option.
// Anything created before a failure is archived again so a failed run leaves no debris.
// With editQuoteId it edits a builder quote in place instead (draft / changes requested only):
// new line items replace the quote's old ones, the quote keeps its id, link and option status.
const { hs, OBJ, batchCreate, batchArchive, loadProducts, loadTemplates, loadDealOptions, loadDeal, findOwnerByEmail, findBuilderLineItems, associatedIds, associate, unassociate } = require('./lib/hubspot.js');
const { quoteUrl, quoteCurrency, pipelineFamily, indexCatalog, buildQuote, cotermRows, refreshCoterms, pipelineAllowsCoterm, isDowngradePipeline, lineItemProperties, validateSubmission, autoQuoteName, dealWrites, builderState, openQuoteConflicts, quoteEditability } = require('./lib/pricing.js');
const { QUOTE_DEFAULTS, QUOTE_SESSION_PROPERTY, QUOTE_STATE_PROPERTY } = require('./lib/config.js');

const ASSOC = {
  lineItemToDeal: 20,
  quoteToDeal: 64,
  quoteToLineItem: 67,
  quoteToContact: 69,
  quoteToCompany: 71, // the buyer company: its name and address print on the quote
  quoteToTemplate: 286,
  quoteToSigner: 702,
  lineItemToQuote: 68,
};
const link = (id, typeId) => ({ to: { id: String(id) }, types: [{ associationCategory: 'HUBSPOT_DEFINED', associationTypeId: typeId }] });

exports.main = async (context) => {
  const payload = context.parameters || {};
  const dealId = String(payload.dealId || '');
  const errors = validateSubmission(payload);
  if (!dealId) errors.push('dealId is required');
  if (errors.length) return { ok: false, errors };

  let products, templates, dealOptions, deal, builder;
  try {
    [products, templates, dealOptions, deal, builder] = await Promise.all([
      loadProducts(),
      loadTemplates(),
      loadDealOptions(),
      loadDeal(dealId),
      // HubSpot passes the signed-in user's email to the function; the card's copy is a fallback.
      findOwnerByEmail(context.userEmail || (payload.builder && payload.builder.email)),
    ]);
  } catch (err) {
    console.error('quote-builder-submit load failed', err.message);
    return { ok: false, errors: [err.message] };
  }
  // Whoever builds the quote owns it and is its seller. HubSpot only lets the quote's owner or its
  // creator click Request approval, and a quote made by an app has no creator, so without this only
  // the deal owner could request approval. The deal and its owner are not changed.
  const sender = builder || deal.owner;
  const quoteOwner = builder || deal.owner;
  if (!sender || !quoteOwner) return { ok: false, errors: ["Couldn't find you as a HubSpot user, and the deal has no owner. Assign a deal owner and try again."] };
  const template = templates.find((t) => t.id === String(payload.setup.templateId));
  if (!template) return { ok: false, errors: ['The selected quote template no longer exists.'] };

  // activeProducts and dealFamily come from the company and deal records here, never from the card,
  // so New / Upsell / Co-term / Downgrade can't be spoofed.
  const setup = Object.assign({}, payload.setup, {
    salesTeam: deal.salesTeam,
    templateType: template.templateType,
    activeProducts: deal.company ? deal.company.activeProducts : null,
    // none on a Downgrade deal (the partner signs a new 12-month commit)
    cotermProducts: !pipelineAllowsCoterm(deal.properties.pipeline) ? [] : deal.company ? deal.company.cotermProducts || [] : null,
    dealFamily: pipelineFamily(deal.properties.pipeline),
    // every line on a Downgrade Pipeline deal is tagged Downgrade
    downgrade: isDowngradePipeline(deal.properties.pipeline),
  });
  // Co-term rows come from the company record (count, plan, minimum); only the rep's discount is kept.
  payload.products = refreshCoterms(payload.products, cotermRows(deal.company, { dealFamily: setup.dealFamily, segment: payload.setup.segment, pipeline: deal.properties.pipeline }));
  // Priced in the deal's currency (CAD deals use each product's CAD price).
  const currency = quoteCurrency(deal.properties.deal_currency_code);
  const catalog = indexCatalog(products, currency);
  const quote = buildQuote(setup, payload.products, payload.ramp, catalog);
  if (quote.blocking.length) return { ok: false, errors: quote.blocking.map((b) => b.error) };
  if (quote.conflicts.length) return { ok: false, errors: quote.conflicts };
  if (!quote.lines.length) return { ok: false, errors: ['Nothing to quote.'] };
  const writes = dealWrites(quote, { setup }, dealOptions.options);
  if (writes.errors.length) return { ok: false, errors: writes.errors };

  const signerId = payload.setup.signerContactId && deal.contacts.some((c) => c.id === String(payload.setup.signerContactId)) ? String(payload.setup.signerContactId) : null;
  const isCpq = template.templateType === 'CPQ_QUOTE';
  if (isCpq && payload.setup.acceptance === 'esignature' && !signerId) return { ok: false, errors: ['E-signature quotes need a signer contact associated with the deal.'] };

  let editing = null;
  if (payload.editQuoteId) {
    editing = deal.quotes.find((q) => q.id === String(payload.editQuoteId));
    if (!editing) return { ok: false, errors: ['That quote is not on this deal.'] };
    const can = quoteEditability(editing);
    if (!can.editable) return { ok: false, errors: [`This quote can't be edited: ${can.reason}`] };
    if (editing.templateType && editing.templateType !== template.templateType) {
      return { ok: false, errors: ["An existing quote can't switch between a CPQ and a legacy template. Pick a template of the same kind, or start a new option."] };
    }
  }

  const sessionId = editing ? editing.session : `qb-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  const lineProps = quote.lines.map((l) => lineItemProperties(l, { billing: setup.billing, rampMonths: quote.ramp.months, sessionId, currency }));
  const created = { dealLines: [], quoteLines: [], quoteId: null };
  // Primary unless the rep says otherwise; the first builder quote on a deal is always primary.
  // An edited quote keeps whatever option status it had.
  const primary = editing ? editing.primary : payload.primary !== false || !deal.quotes.some((q) => q.builder);
  const affected = openQuoteConflicts(deal.quotes.filter((q) => !editing || q.id !== editing.id), deal.properties, writes.properties).quotes;
  const title = (payload.setup.quoteName || '').trim() || autoQuoteName(deal.company && deal.company.name, payload.products, quote.anyRamp ? quote.ramp.months : 0, catalog);
  const quoteProps = {
    hs_title: title.slice(0, 250),
    hs_expiration_date: payload.setup.expirationDate,
    hs_template_type: template.templateType,
    hs_language: QUOTE_DEFAULTS.language,
    hs_currency: currency,
    hs_payment_enabled: String(QUOTE_DEFAULTS.paymentEnabled),
    hubspot_owner_id: quoteOwner.id,
    hs_sender_firstname: sender.firstName,
    hs_sender_lastname: sender.lastName,
    hs_sender_email: sender.email,
    [QUOTE_SESSION_PROPERTY]: sessionId,
    [QUOTE_STATE_PROPERTY]: builderState({ setup: payload.setup, products: payload.products, ramp: payload.ramp }, writes.properties),
  };
  if (isCpq) quoteProps.hs_acceptance_method = payload.setup.acceptance || 'esignature';
  else if (!editing) quoteProps.hs_status = 'DRAFT';
  const result = (quoteId) => ({
    ok: true,
    edited: !!editing,
    quoteId,
    quoteUrl: quoteUrl(context.accountId, quoteId, template.templateType, editing ? editing.progressionStatus : 'DRAFT'),
    title,
    templateType: template.templateType,
    lineCount: lineProps.length,
    primary,
    replaced: 0,
    openQuotesAffected: affected.map((q) => ({ id: q.id, title: q.title })),
    approval: quote.approval,
    totals: quote.totals,
    dealProperties: writes.properties,
    warnings: writes.warnings,
  });

  if (editing) return editInPlace({ editing, dealId, deal, template, signerId, isCpq, payload, lineProps, quoteProps, primary, writes, result });

  try {
    if (primary) created.dealLines = await batchCreate('line_items', lineProps.map((properties) => ({ properties, associations: [link(dealId, ASSOC.lineItemToDeal)] })));
    created.quoteLines = await batchCreate('line_items', lineProps.map((properties) => ({ properties })));

    const associations = [link(dealId, ASSOC.quoteToDeal), link(template.id, ASSOC.quoteToTemplate)]
      .concat(created.quoteLines.map((li) => link(li.id, ASSOC.quoteToLineItem)));
    if (deal.company) associations.push(link(deal.company.id, ASSOC.quoteToCompany));
    if (signerId) {
      associations.push(link(signerId, ASSOC.quoteToContact));
      if (isCpq && payload.setup.acceptance === 'esignature') associations.push(link(signerId, ASSOC.quoteToSigner));
    }
    const created_quote = await hs(`${OBJ}/quotes`, { method: 'POST', body: { properties: quoteProps, associations } });
    created.quoteId = String(created_quote.id);

    await hs(`${OBJ}/deals/${encodeURIComponent(dealId)}`, { method: 'PATCH', body: { properties: writes.properties } });

    let replaced = 0;
    if (primary) {
      const old = await findBuilderLineItems(dealId, sessionId);
      if (old.length) await batchArchive('line_items', old);
      replaced = old.length;
    }

    return Object.assign(result(created.quoteId), { replaced });
  } catch (err) {
    console.error('quote-builder-submit failed; rolling back', err.message, err.details || '');
    const rollbackErrors = [];
    if (created.quoteId) await hs(`${OBJ}/quotes/${created.quoteId}`, { method: 'DELETE' }).catch((e) => rollbackErrors.push(e.message));
    const lineIds = created.dealLines.concat(created.quoteLines).map((li) => li.id);
    if (lineIds.length) await batchArchive('line_items', lineIds).catch((e) => rollbackErrors.push(e.message));
    return { ok: false, errors: [err.message].concat(rollbackErrors.map((m) => `Rollback: ${m}`)) };
  }
};

// Edit a builder quote in place: same quote id, new line items, updated properties.
async function editInPlace({ editing, dealId, deal, template, signerId, isCpq, payload, lineProps, quoteProps, primary, writes, result }) {
  const quoteId = editing.id;
  const created = { dealLines: [], quoteLines: [] };
  let before = null;
  try {
    const oldQuoteLines = await associatedIds('quotes', quoteId, 'line_items');
    const current = (await hs(`${OBJ}/quotes/${encodeURIComponent(quoteId)}?properties=${Object.keys(quoteProps).join(',')}`)).properties || {};
    before = Object.fromEntries(Object.keys(quoteProps).map((k) => [k, current[k] == null ? '' : current[k]]));

    if (primary) created.dealLines = await batchCreate('line_items', lineProps.map((properties) => ({ properties, associations: [link(dealId, ASSOC.lineItemToDeal)] })));
    created.quoteLines = await batchCreate('line_items', lineProps.map((properties) => ({ properties, associations: [link(quoteId, ASSOC.lineItemToQuote)] })));
    await hs(`${OBJ}/quotes/${encodeURIComponent(quoteId)}`, { method: 'PATCH', body: { properties: quoteProps } });

    const templates = await associatedIds('quotes', quoteId, 'quote_template');
    if (!templates.includes(String(template.id))) {
      for (const id of templates) await unassociate('quotes', quoteId, 'quote_template', id);
      await associate('quotes', quoteId, 'quote_template', template.id, [ASSOC.quoteToTemplate]);
    }
    const contacts = await associatedIds('quotes', quoteId, 'contacts');
    for (const id of contacts) await unassociate('quotes', quoteId, 'contacts', id);
    if (signerId) await associate('quotes', quoteId, 'contacts', signerId, isCpq && payload.setup.acceptance === 'esignature' ? [ASSOC.quoteToContact, ASSOC.quoteToSigner] : [ASSOC.quoteToContact]);
    // Quotes made before the company association was added get it on their next update.
    if (deal.company && !(await associatedIds('quotes', quoteId, 'companies')).includes(String(deal.company.id))) {
      await associate('quotes', quoteId, 'companies', deal.company.id, [ASSOC.quoteToCompany]);
    }

    if (oldQuoteLines.length) await batchArchive('line_items', oldQuoteLines);
    await hs(`${OBJ}/deals/${encodeURIComponent(dealId)}`, { method: 'PATCH', body: { properties: writes.properties } });

    let replaced = 0;
    if (primary) {
      const old = await findBuilderLineItems(dealId, null, created.dealLines.map((li) => li.id));
      if (old.length) await batchArchive('line_items', old);
      replaced = old.length;
    }
    return Object.assign(result(quoteId), { replaced });
  } catch (err) {
    console.error('quote-builder-submit edit failed; rolling back', err.message, err.details || '');
    const rollbackErrors = [];
    const lineIds = created.dealLines.concat(created.quoteLines).map((li) => li.id);
    if (lineIds.length) await batchArchive('line_items', lineIds).catch((e) => rollbackErrors.push(e.message));
    if (before) await hs(`${OBJ}/quotes/${encodeURIComponent(quoteId)}`, { method: 'PATCH', body: { properties: before } }).catch((e) => rollbackErrors.push(e.message));
    return { ok: false, errors: [err.message].concat(rollbackErrors.map((m) => `Rollback: ${m}`)) };
  }
}
