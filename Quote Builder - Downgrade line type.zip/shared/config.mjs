// Quote Builder business configuration.
// Source of truth lives in /shared. `npm run sync` copies it into the card bundle (ESM)
// and the app functions (CommonJS). Edit here, never in the copies.

// HubSpot API version (date-based). Legacy /v3 and /v4 paths stop working September 2027.
// To move to a newer version, change this one value and run the tests.
export const HS_API_VERSION = '2026-09';
export const HS_PATHS = {
  objects: `/crm/objects/${HS_API_VERSION}`, // /{objectType}, /{objectType}/{id}, /batch/*, /search, /{id}/associations/...
  associations: `/crm/associations/${HS_API_VERSION}`, // /{fromType}/{toType}/batch/read
  properties: `/crm/properties/${HS_API_VERSION}`, // /{objectType}, /{objectType}/{name}, /groups, /batch/read
  owners: `/crm/owners/${HS_API_VERSION}`, // ?email=, /{ownerId}
};

// Product families the builder sells. Keys match the `qb_family` product property.
export const FAMILIES = {
  autoelevate: {
    label: 'AutoElevate',
    unit: 'agents',
    unitSingular: 'Agent',
    editions: [
      { value: 'standard', label: 'Standard' },
      { value: 'advanced', label: 'Advanced' },
    ],
  },
  password: {
    label: 'Password Manager',
    unit: 'users',
    unitSingular: 'User',
    editions: [
      { value: 'pack', label: 'User Packs (2026)' },
      { value: 'commit', label: 'User Commit (PB6)' },
    ],
  },
  dns: {
    label: 'DNS Filtering',
    unit: 'devices',
    unitSingular: 'Device',
    editions: [{ value: 'standard', label: 'Standard' }],
  },
  timus: {
    label: 'Timus SASE',
    unit: 'users',
    unitSingular: 'User',
    editions: [{ value: 'advanced', label: 'Advanced' }],
  },
  optimize365: {
    label: 'Optimize365',
    unit: 'users',
    unitSingular: 'User',
    // MSP reps pick the pricing: per user (the original MSP SKUs) or per tenant (5–500 tenant plans, Nov 2026).
    // Enterprise is per user only. An edition can set its own unit and the segments it's sold in.
    pickerLabel: 'Pricing',
    editions: [
      { value: 'standard', label: 'Per user' },
      { value: 'tenant', label: 'Per tenant', unit: 'tenants', unitSingular: 'Tenant', segments: ['MSP'] },
    ],
  },
  // One-off SKUs: custom products built for a single deal, kept in the "One-Off SKUs" product folder.
  // The rep picks the product; price and billing frequency come from the product itself.
  oneoff: {
    label: 'One-off SKU',
    unit: 'units',
    unitSingular: 'Unit',
    editions: [{ value: 'standard', label: 'One-off' }],
  },
  bundle: {
    label: 'CyberFOX Bundle',
    unit: 'users',
    unitSingular: 'User',
    editions: [{ value: 'standard', label: 'Standard' }],
  },
};

// Optimize365 ramps (MSP and Enterprise): free months added on top of a 12-month plan, so only a 13-, 14- or
// 15-month agreement can ramp (1, 2 or 3 free months, 100% off), and only when paid monthly. Annual (paid
// upfront) and month-to-month Optimize quotes never ramp. 3 months allowed from Nov 2026 (was 2).
export const OPTIMIZE_RAMP = { family: 'optimize365', planMonths: 12, maxMonths: 3 };

// Products reps can add (in this order). CyberFOX Bundles are being retired (SKUs off Jan 1), so they
// can't be added to new quotes; saved quotes that already include a bundle still load and edit.
export const FAMILY_ORDER = ['autoelevate', 'password', 'dns', 'timus', 'optimize365', 'oneoff'];
// Optimize TDR (Nov 2026): an add-on to MSP per-tenant Optimize365, on the same row. One "Optimize TDR" line,
// volume priced: every user is billed at the rate of the tier the total falls into (6,000 users = 6,000 × $0.85).
// HubSpot's API doesn't expose a product's volume tiers, so they live here: keep them in step with the
// "Optimize TDR" product. The product is tagged qb_edition = tdr (see tag-products).
export const OPTIMIZE_TDR = {
  edition: 'tdr',
  currency: 'USD', // the tiers below are USD; add a currency here (with its own tiers) before quoting TDR in it
  withEdition: 'tenant',
  sku: 'Optimize TDR',
  tiers: [
    { from: 1, to: 4999, price: 1.0 },
    { from: 5000, to: 7499, price: 0.85 },
    { from: 7500, to: 14999, price: 0.7 },
    { from: 15000, to: 49999, price: 0.5 },
    { from: 50000, to: null, price: 0.5 },
  ],
};

// Product folder whose active products reps can quote as one-off SKUs (read live; no tagging needed).
export const ONE_OFF_FOLDER = 'One-Off SKUs';
// Which product family a one-off SKU belongs to, read from its name/SKU (for quote wording, templates and
// product rules such as Optimize365 ramps). First match wins.
/** @type {Array<[string, RegExp]>} */
export const ONE_OFF_FAMILY_PATTERNS = [
  ['autoelevate', /autoelevate|(^|[^a-z])ae([^a-z]|$)/i],
  ['optimize365', /optimize/i],
  ['dns', /dns/i],
  ['password', /password|(^|[^a-z])pb([^a-z]|$)/i],
  ['timus', /timus/i],
];

export const SEGMENTS = [
  { value: 'MSP', label: 'MSP' },
  { value: 'ENT', label: 'Enterprise' },
];

export const BILLING = {
  monthly: { label: 'Monthly', frequency: 'monthly', periodsPerYear: 12 },
  annual: { label: 'Annual (billed yearly)', frequency: 'annually', periodsPerYear: 1 },
  m2m: { label: 'Month-to-month', frequency: 'monthly', periodsPerYear: 12 },
};

export const MAX_RAMP_MONTHS = 12; // total across all ramp stages
// A ramp can step down in stages, e.g. 2 months free then 2 months at 50% off.
export const MAX_RAMP_STAGES = 4;

// Approval policy (mirrors the Commerce Hub approval workflow; keep them in sync).
export const APPROVAL = {
  discountThresholdPct: 30, // discounts at or above this need a sales manager
  rampMonthsThreshold: 4, // ramps this long or longer (total of all stages) need approval; matches the Commerce Hub workflow (> 3)
  approversByTeam: {
    MSP: 'Tina Harvey (MSP Sales Manager)',
    ENT: 'Adam Friedman (ENT Sales Manager)',
    AM: 'Julie Webb (AM Sales Manager)',
  },
  fallbackApprover: 'Operations team',
};

// Timus: the commit is a single "Monthly Minimum" line at the minimum the rep sets (SKU price by default).
// Satisfaction-guarantee agreements use the SATGAT SKUs instead (keyed by minimum).
export const TIMUS = {
  minimumSku: 'Timus SASE - Monthly Minimum',
  satgatSkuByMinimum: {
    250: 'Timus SASE - SATGAT',
    500: 'Timus SASE - SATGAT II',
    1000: 'Timus SASE - SATGAT III',
  },
};

// Line item bookkeeping so the builder only ever replaces lines it created.
export const LINE_SOURCE_PROPERTY = 'qb_source';
export const LINE_SOURCE_VALUE = 'quote_builder';
export const LINE_SESSION_PROPERTY = 'qb_session_id';

// Line item fields the NetSuite auto-split reads (Nov 2026).
// qb_family: the product a line belongs to (a one-off SKU counts as its product's family when the name
// says which, else "oneoff"). The auto-split moves each family's lines to that product's own deal.
export const LINE_FAMILY_PROPERTY = 'qb_family';
// qb_line_type: New / Upsell / Co-term / Downgrade. Internal values exactly as created in HubSpot ("New",
// "Upsell" and "Downgrade" are capitalized, "coterm" is not). Every line on a Downgrade Pipeline deal is
// Downgrade. New or Upsell is set from the company's product status; Co-term is
// the rep's choice: an existing product re-signed so its renewal lines up with the new product. Co-term
// lines stay on the deal they were sold on (no extra deal or Sale Review).
export const LINE_TYPE_PROPERTY = 'qb_line_type';
export const LINE_TYPES = { new: 'New', upsell: 'Upsell', coterm: 'coterm', downgrade: 'Downgrade' };
export const LINE_TYPE_LABELS = { New: 'New', Upsell: 'Upsell', coterm: 'Co-term', Downgrade: 'Downgrade' };
// The product each deal pipeline sells (Sales and Upsell), so Co-term is never offered on the deal's own
// product: on an AutoElevate Upsell deal the AutoElevate line is the upsell itself.
export const PIPELINE_FAMILY = {
  '907910': 'autoelevate', // AutoElevate Sales
  '7659799': 'autoelevate', // AutoElevate Upsell
  '6643621': 'password', // Password Manager Sales
  '7687975': 'password', // Password Manager Upsell
  '800440185': 'dns', // DNS Filtering Sales
  '800641452': 'dns', // DNS Filtering Upsell
  '897549164': 'timus', // Timus Sales
  '904388020': 'timus', // Timus Upsell
  '917642399': 'optimize365', // Optimize Sales
  '933312031': 'optimize365', // Optimize Upsell
};
// Company properties that say whether the partner is already on a product (Active = an upsell).
export const COMPANY_PRODUCT_STATUS = {
  autoelevate: { property: 'ae_product', active: 'AE Active' },
  password: { property: 'pb_product', active: 'PB Active' },
  dns: { property: 'dns_product', active: 'DNS Active' },
  timus: { property: 'timus_product', active: 'Timus Active' },
  optimize365: { property: 'optimize_product', active: 'Optimize Active' },
};

// Automatic co-term (Nov 2026). When the builder opens, every product the company is Active on (other
// than the deal's own product) gets a Co-term row sized from the company's current commit, in the
// segment picked on Setup: 150 agents = the 100-agent plan + 50 additional agents. The count and plan come
// from the company record and are locked; the rep can only change the discount, which starts at the
// company's Current Discount (Initial Discount when Current is unknown; both stored as fractions, 0.1 = 10%).
// The row can't be removed (every active product is co-termed) and doesn't ramp. Only a product paid Month-to-Month is co-termed (its Payment Terms on the
// company): Annual Payments, Quarterly, One Time or blank never co-term, so that product is an Upsell.
export const COTERM_COMMITS = {
  autoelevate: {
    quantity: 'ae_agent_commit',
    featureType: 'ae_sku_type',
    paymentTerms: 'ae_payment_terms',
    currentDiscount: 'ae_current_discount__percentage____number_based',
    initialDiscount: 'ae_initial_discount____property_',
  },
  password: {
    quantity: 'pb_user_commit',
    edition: 'pack', // 2026 User Packs: round up to whole packs
    paymentTerms: 'pb_payment_terms',
    currentDiscount: 'pb_current_discount__percentage____number_based',
    initialDiscount: 'pb_initial_discount____property_',
  },
  dns: {
    quantity: 'dns_device_commit',
    paymentTerms: 'dns_payment_terms',
    currentDiscount: 'dns_current_discount__percentage____number_based',
    initialDiscount: 'dns_initial_discount____property_',
  },
  timus: {
    minimum: 'timus_committed_mrr', // a spend commit, not a user commit
    users: 'timus_user_commit',
    paymentTerms: 'timus_payment_terms',
    currentDiscount: 'timus_current_discount__property',
    initialDiscount: 'timus_initial_discount__property',
  },
  optimize365: {
    quantity: 'optimize_user_commit',
    tenants: 'optimize_tenant_commit',
    paymentTerms: 'optimize_payment_terms',
    currentDiscount: 'optimize_current_discount__property',
    initialDiscount: 'optimize_initial_discount__property',
  },
};
// The only company Payment Terms value that co-terms.
export const COTERM_PAYMENT_TERMS = ['Month-to-Month'];
// Deal pipelines that never co-term: a downgrade always puts the partner on a new 12-month commit.
export const NO_COTERM_PIPELINES = {
  '30582866': 'Downgrade Pipeline',
};
// Deal pipelines whose lines are all tagged Downgrade (qb_line_type).
export const DOWNGRADE_PIPELINES = {
  '30582866': 'Downgrade Pipeline',
};
// The company's AE Feature Type → the feature type the AutoElevate co-term is priced on.
// Advanced (GrandFathered) partners co-term on Advanced SKUs.
export const COTERM_AE_FEATURE = { Standard: 'Standard', Advanced: 'Advanced', 'Advanced (GrandFathered)': 'Advanced' };
// How the company properties are named on screen.
export const COTERM_PROPERTY_LABELS = {
  ae_agent_commit: 'AE Agent Commit',
  ae_sku_type: 'AE Feature Type',
  pb_user_commit: 'PM User Commit',
  dns_device_commit: 'DNS Device Commit',
  timus_committed_mrr: 'Timus Committed MRR',
  timus_user_commit: 'Timus User Commit',
  optimize_user_commit: 'Optimize User Commit',
  optimize_tenant_commit: 'Optimize Tenant Commit',
  ae_payment_terms: 'AE Payment Terms',
  pb_payment_terms: 'PM Payment Terms',
  dns_payment_terms: 'DNS Payment Terms',
  timus_payment_terms: 'Timus Payment Terms',
  optimize_payment_terms: 'Optimize Payment Terms',
  ae_current_discount__percentage____number_based: 'AE Current Discount',
  ae_initial_discount____property_: 'AE Initial Discount',
  pb_current_discount__percentage____number_based: 'PM Current Discount',
  pb_initial_discount____property_: 'PM Initial Discount',
  dns_current_discount__percentage____number_based: 'DNS Current Discount',
  dns_initial_discount____property_: 'DNS Initial Discount',
  timus_current_discount__property: 'Timus Current Discount',
  timus_initial_discount__property: 'Timus Initial Discount',
  optimize_current_discount__property: 'Optimize Current Discount',
  optimize_initial_discount__property: 'Optimize Initial Discount',
};

// Multiple quotes per deal ("options"). Each builder quote stores its run id and the builder
// state so a rep can start a new option from it or make it the primary option later.
export const QUOTE_SESSION_PROPERTY = 'qb_session_id';
export const QUOTE_STATE_PROPERTY = 'qb_builder_state';
// HubSpot freezes the deal-property tokens on a quote once it is published (or out for
// signature). Quotes still in these progression statuses read the deal's current values,
// so writing new printed values would change them too.
export const QUOTE_OPEN_STATUSES = ['DRAFT', 'PENDING_APPROVAL', 'CHANGES_REQUESTED'];
export const QUOTE_IGNORED_STATUSES = ['VOID'];
// Builder quotes reps can edit in place. Pending approval must be recalled first; published or
// signed quotes are locked by HubSpot (start a new option instead).
export const QUOTE_EDITABLE_STATUSES = ['DRAFT', 'CHANGES_REQUESTED'];

// When true, post-ramp lines get "Delayed billing start by months" = ramp length.
// Off by default to match how ramps are entered today (Sale Review groups ramp segments).
export const SET_BILLING_DELAY_AFTER_RAMP = false;

// Quote templates: suggest templates whose names match the products on the quote.
export const TEMPLATE_HINTS = {
  autoelevate: 'autoelevate',
  password: 'password|pb',
  dns: 'dns',
  timus: 'timus',
  optimize365: 'optimize',
  bundle: 'bundle',
};
// Template names containing any of these are hidden from reps (one-off / internal templates).
export const TEMPLATE_HIDE = ['one off', 'one-off', 'clone of', 'sponsorship', 'default '];

// Deal properties the card reads.
export const DEAL_PROPERTIES = [
  'dealname',
  'hubspot_owner_id',
  'sales_team',
  'payment_method',
  'invoice_terms',
  'payment_terms',
  'agreement_length',
  'sku_type',
  'timus_price_per_user',
  'timus_price_per_gateway',
  'new_minimum_commitment_amount',
  'ae_feature_type_details',
  'deal_currency_code',
  'pipeline',
];
// Printed deal properties compared against open quotes before they are overwritten.
export const PRINTED_DEAL_PROPERTIES = [
  'agreement_length',
  'payment_terms',
  'payment_method',
  'invoice_terms',
  'sku_type',
  'ae_feature_type_details',
  'timus_price_per_user',
  'timus_price_per_gateway',
  'new_minimum_commitment_amount',
];

// Deal properties that print on quote templates as tokens. Their dropdown options are read
// live from HubSpot so the card can never write a value the property doesn't accept.
export const QUOTE_TOKEN_PROPERTIES = {
  agreementLength: 'agreement_length', // "15 Months", "12 Months - Month-to-Month"
  paymentFrequency: 'payment_terms', // label "Payment Frequency"
  paymentMethod: 'payment_method',
  invoiceTerms: 'invoice_terms',
  aeFeatureType: 'sku_type', // label "AE Feature Type"
  aeFeatureTypeDetails: 'ae_feature_type_details',
};
// Promo is not set by the builder (removed from Setup); a deal's Promo is left as it is.
export const ENUM_PROPERTIES = ['agreement_length', 'payment_terms', 'payment_method', 'invoice_terms', 'sku_type'];

// Agreement Length value for month-to-month quotes (the option HubSpot labels "Month-to-Month").
export const AGREEMENT_LENGTH_M2M = '12 Months - Month-to-Month';
export const AGREEMENT_LENGTH_DEFAULT = '12 Months';
// Invoice Terms every new quote starts with, whatever the deal already holds; the rep can change it on Setup.
export const INVOICE_TERMS_DEFAULT = 'Due Upon Receipt';
// Contract Term (contract_term) is not shown or written: Agreement Length is what quotes print.
// Turn on only if something downstream (e.g. Sale Review) still reads contract_term.
export const WRITE_CONTRACT_TERM = false;
// Payment Frequency default per billing choice; the rep can override (e.g. Quarterly).
export const PAYMENT_FREQUENCY_DEFAULT = { monthly: 'Month-to-Month', m2m: 'Month-to-Month', annual: 'Annual Payments' };
export const PAYMENT_FREQUENCY_HIDDEN = ['One Time'];

// Used only if the live property options can't be read.
export const FALLBACK_OPTIONS = {
  payment_terms: [
    { value: 'Month-to-Month', label: 'Monthly' },
    { value: 'Quarterly', label: 'Quarterly' },
    { value: 'Annual Payments', label: 'Annual Payments' },
  ],
  payment_method: [
    { value: 'Credit Card', label: 'Credit Card' },
    { value: 'ACH', label: 'ACH' },
    { value: 'Check', label: 'Check' },
  ],
  invoice_terms: ['Due Upon Receipt', 'Net-30', 'Net-45', 'Net-60', 'Net-90'].map((v) => ({ value: v, label: v })),
  agreement_length: [],
  sku_type: [],
};

// AutoElevate feature type → which SKU edition prices it, and the AE Feature Type Details text
// the AutoElevate quote template prints. {tier} is replaced with the commit tier.
export const AE_FEATURE_TYPES = [
  {
    value: 'Standard',
    edition: 'standard',
    details:
      'Elevation. Additional agents over the minimum commitment of this plan will be billed at the same price per agent. Usage of Advanced features Blocker and Just-in-Time Admin Login will result in additional charges. Unlimited User (Technician) & Company licenses included',
  },
  {
    value: 'Advanced',
    edition: 'advanced',
    details:
      'Elevation, Blocker, and Just-In-Time Admin Login. Additional agents over the minimum commitment of this plan will be billed at the same price per agent. Unlimited User (Technician) & Company licenses included',
  },
];
// Retired feature types: no longer offered. A saved quote (or a deal) that still has one opens as Standard.
export const AE_FEATURE_TYPES_RETIRED = ['Advanced (GrandFathered)'];

export const RAMP_NAME_PREFIX = 'RAMP ';
// paymentEnabled: false matches every CyberFOX CPQ quote today (no online payment on the quote).
// With payments on, HubSpot requires every invoice to be $35+, which blocks ramp months.
export const QUOTE_DEFAULTS = { language: 'en', currency: 'USD', expirationDays: 30, paymentEnabled: false };

// Currencies the product library prices in (hs_price_<code> on each product). A quote is priced in its deal's
// currency (Deal currency code); a SKU with no price in that currency stops the quote instead of falling back to USD.
export const CURRENCIES = ['USD', 'CAD', 'GBP', 'EUR', 'AUD'];
