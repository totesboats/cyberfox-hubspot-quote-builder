// Pure pricing, ramp and approval logic shared by the card (live preview) and the
// submit function (authoritative rebuild). No HubSpot calls in here.
import {
  FAMILIES,
  BILLING,
  MAX_RAMP_MONTHS,
  MAX_RAMP_STAGES,
  APPROVAL,
  TIMUS,
  RAMP_NAME_PREFIX,
  SET_BILLING_DELAY_AFTER_RAMP,
  LINE_SOURCE_PROPERTY,
  LINE_SOURCE_VALUE,
  LINE_SESSION_PROPERTY,
  TEMPLATE_HINTS,
  TEMPLATE_HIDE,
  AE_FEATURE_TYPES,
  AGREEMENT_LENGTH_M2M,
  PAYMENT_FREQUENCY_DEFAULT,
  WRITE_CONTRACT_TERM,
  QUOTE_OPEN_STATUSES,
  QUOTE_IGNORED_STATUSES,
  PRINTED_DEAL_PROPERTIES,
  QUOTE_EDITABLE_STATUSES,
  OPTIMIZE_RAMP,
  ONE_OFF_FOLDER,
  ONE_OFF_FAMILY_PATTERNS,
  OPTIMIZE_TDR,
  CURRENCIES,
  QUOTE_DEFAULTS,
  LINE_FAMILY_PROPERTY,
  LINE_TYPE_PROPERTY,
  LINE_TYPES,
  LINE_TYPE_LABELS,
  COMPANY_PRODUCT_STATUS,
  PIPELINE_FAMILY,
  COTERM_COMMITS,
  COTERM_AE_FEATURE,
  COTERM_PROPERTY_LABELS,
  COTERM_PAYMENT_TERMS,
  NO_COTERM_PIPELINES,
  DOWNGRADE_PIPELINES,
  FAMILY_ORDER,
} from './config.mjs';

export function toNum(v, fallback = 0) {
  const n = typeof v === 'number' ? v : parseFloat(v);
  return Number.isFinite(n) ? n : fallback;
}

export function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

export function clamp(n, min, max) {
  return Math.min(max, Math.max(min, n));
}

export function formatMoney(n, decimals = 2) {
  return '$' + toNum(n).toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}

export function formatInt(n) {
  return Math.round(toNum(n)).toLocaleString('en-US');
}

// ---------------------------------------------------------------------------
// Catalog
// ---------------------------------------------------------------------------

// { USD: 1050, CAD: 1390, ... } from a product's hs_price_<currency> properties (only currencies that are set).
export function productPrices(p) {
  const out = {};
  for (const code of CURRENCIES) {
    const v = p[`hs_price_${code.toLowerCase()}`];
    if (v != null && v !== '' && Number.isFinite(Number(v))) out[code] = Number(v);
  }
  if (out.USD == null && p.price != null && p.price !== '' && Number.isFinite(Number(p.price))) out.USD = Number(p.price);
  return out;
}

// Blocking error text when products have no price in the quote's currency (null when all are priced).
function missingPriceError(products, currency) {
  const missing = products.filter((p) => p && p.missingPrice);
  if (!missing.length) return null;
  const skus = missing.map((p) => p.sku || p.name).join(', ');
  return `No ${currency} price on ${skus} in the product library. Add the ${currency} price to quote this deal in ${currency}.`;
}

// The deal's currency code, normalized (USD when unset).
export function quoteCurrency(code) {
  const c = String(code || QUOTE_DEFAULTS.currency).trim().toUpperCase();
  return c || QUOTE_DEFAULTS.currency;
}

export function normalizeProduct(record) {
  const p = record.properties || record;
  const tierRaw = p.qb_tier;
  return {
    id: String(record.id != null ? record.id : p.hs_object_id),
    name: (p.name || '').trim(),
    sku: (p.hs_sku || '').trim(),
    // Multi-currency portals store the list price in hs_price_<currency>. `price` is USD until indexCatalog
    // picks the deal's currency.
    price: toNum(p.hs_price_usd != null && p.hs_price_usd !== '' ? p.hs_price_usd : p.price),
    prices: productPrices(p),
    family: p.qb_family || null,
    edition: p.qb_edition || 'standard',
    segment: p.qb_segment || 'MSP',
    billing: p.qb_billing || 'monthly',
    tier: tierRaw != null && tierRaw !== '' ? toNum(tierRaw, null) : null,
    component: p.qb_component || 'base',
    folder: (p.hs_folder || '').replace(/ \(auto_generated.*$/, '').trim(),
    frequency: p.recurringbillingfrequency || '',
  };
}

// The product family a one-off SKU belongs to (by its name/SKU), and its edition (Advanced in the name → advanced).
export function oneOffFamily(p) {
  const text = `${p.name || ''} ${p.sku || ''}`;
  const hit = ONE_OFF_FAMILY_PATTERNS.find(([, re]) => re.test(text));
  return { baseFamily: hit ? hit[0] : null, baseEdition: /advanced/i.test(text) ? 'advanced' : 'standard' };
}

export function catalogKey(family, edition, segment, billing) {
  return [family, edition, segment, billing].join('|');
}

// Builds { tiers: { key: { tier: { base, additional } } }, timus: { minimum, satgat }, oneOffs, issues }
// `currency` is the deal's currency: every product is priced from its hs_price_<currency>. A product with no
// price in that currency is kept but marked missingPrice, so quoting it is a blocking error (never USD instead).
export function indexCatalog(records, currency) {
  const cur = quoteCurrency(currency);
  const tiers = {};
  const timus = { minimum: null, satgat: {} };
  const oneOffs = [];
  const issues = [];
  for (const record of records || []) {
    const p = normalizeProduct(record);
    p.currency = cur;
    p.missingPrice = p.prices[cur] == null;
    p.price = p.missingPrice ? 0 : p.prices[cur];
    // One-off SKUs are picked by the rep from their folder, never by tier.
    if (p.folder === ONE_OFF_FOLDER) {
      oneOffs.push(Object.assign(p, oneOffFamily(p)));
      continue;
    }
    if (!p.family || !FAMILIES[p.family]) continue;
    if (p.family === 'timus') {
      if (p.component === 'minimum') timus.minimum = p;
      else if (p.component === 'satgat' && p.tier) timus.satgat[p.tier] = p;
      continue;
    }
    if (!p.tier) {
      issues.push(`${p.sku || p.id}: qb_tier is empty`);
      continue;
    }
    const key = catalogKey(p.family, p.edition, p.segment, p.billing);
    const slot = p.component === 'additional' ? 'additional' : 'base';
    tiers[key] = tiers[key] || {};
    tiers[key][p.tier] = tiers[key][p.tier] || {};
    if (tiers[key][p.tier][slot]) {
      issues.push(`Two ${slot} SKUs for ${key} tier ${p.tier}: ${tiers[key][p.tier][slot].sku} and ${p.sku}`);
      continue;
    }
    tiers[key][p.tier][slot] = p;
  }
  oneOffs.sort((a, b) => a.name.localeCompare(b.name));
  return { tiers, timus, oneOffs, issues, currency: cur };
}

// Quote templates (CRM objects API, quote_templates) → rep-facing list.
export function normalizeTemplates(records) {
  const typeMap = { cpq_template: 'CPQ_QUOTE', customizable_quote_template: 'CUSTOMIZABLE_QUOTE_TEMPLATE' };
  return (records || [])
    .map((r) => {
      const p = r.properties || r;
      const name = (p.hs_name || '').trim();
      const templateType = typeMap[p.hs_type];
      const families = Object.keys(TEMPLATE_HINTS).filter((f) => new RegExp(TEMPLATE_HINTS[f], 'i').test(name));
      return { id: String(r.id), name, templateType, families };
    })
    .filter((t) => t.templateType && t.name && !TEMPLATE_HIDE.some((h) => t.name.toLowerCase().includes(h)))
    .sort((a, b) => (a.templateType === b.templateType ? a.name.localeCompare(b.name) : a.templateType === 'CPQ_QUOTE' ? -1 : 1));
}

// Best template for the families on the quote: CPQ first, most families covered.
export function suggestTemplate(templates, families) {
  const wanted = Array.from(new Set(families || []));
  let best = null;
  let bestScore = -1;
  for (const t of templates || []) {
    const covered = wanted.filter((f) => t.families.includes(f)).length;
    if (!covered) continue;
    const score = covered * 10 + (t.templateType === 'CPQ_QUOTE' ? 5 : 0) - t.families.filter((f) => !wanted.includes(f)).length;
    if (score > bestScore) {
      best = t;
      bestScore = score;
    }
  }
  return best;
}

// ---------------------------------------------------------------------------
// Pricing one product row
// ---------------------------------------------------------------------------

// What a row counts in: the edition's unit when it has one (Optimize365 per tenant), else the family's.
export function unitsFor(familyKey, edition) {
  const fam = FAMILIES[familyKey] || {};
  const ed = (fam.editions || []).find((e) => e.value === edition) || {};
  return { unit: ed.unit || fam.unit, unitSingular: ed.unitSingular || fam.unitSingular };
}

// The editions a segment can quote (Optimize365 per tenant is MSP only).
export function editionsFor(familyKey, segment) {
  const fam = FAMILIES[familyKey] || {};
  return (fam.editions || []).filter((e) => !e.segments || e.segments.includes(segment));
}

// Optimize TDR volume price for a user count: the rate of the tier the total falls into.
export function tdrTier(users) {
  const n = Math.max(0, Math.round(toNum(users)));
  if (!n) return null;
  return OPTIMIZE_TDR.tiers.find((t) => n >= t.from && (t.to == null || n <= t.to)) || null;
}

function makeLine(fields) {
  const gross = round2(fields.quantity * fields.unitPrice);
  const net = round2(gross * (1 - fields.discountPct / 100));
  return Object.assign({}, fields, {
    gross,
    net,
    mrr: fields.annual ? net / 12 : net,
    listMrr: fields.annual ? gross / 12 : gross,
  });
}

// Every commit tier for `quantity`. `best` is the default pick: the highest commit tier at or
// below the count plus overage (900 agents = 750 tier + 150 additional, even when the 1,000 tier
// lists a few dollars less), or the smallest tier when the count is below every tier. Pack-style
// SKUs (no overage SKU) default to the cheapest pack combination. `cheapest` is the lowest list price.
export function tierOptionsFor(tiersForKey, quantity) {
  const options = Object.keys(tiersForKey || {})
    .map(Number)
    .sort((a, b) => a - b)
    .filter((t) => tiersForKey[t].base)
    .map((t) => {
      const base = tiersForKey[t].base;
      const additional = tiersForKey[t].additional || null;
      let baseQty;
      let addQty = 0;
      let cost;
      if (additional) {
        baseQty = 1;
        addQty = Math.max(0, quantity - t);
        cost = base.price + addQty * additional.price;
      } else {
        // Pack-style SKUs (no overage SKU): buy enough packs to cover the count.
        baseQty = Math.max(1, Math.ceil(quantity / t));
        cost = baseQty * base.price;
      }
      return { tier: t, base, additional, baseQty, addQty, cost: round2(cost) };
    });
  let cheapest = options[0] || null;
  for (const o of options) if (o.cost < cheapest.cost - 1e-9) cheapest = o;
  const withOverage = options.filter((o) => o.additional);
  let best = cheapest;
  if (withOverage.length) {
    const atOrBelow = withOverage.filter((o) => o.tier <= quantity);
    best = atOrBelow.length ? atOrBelow[atOrBelow.length - 1] : withOverage[0];
  }
  return { options, best, cheapest };
}

export function priceProduct(input, setup, catalog) {
  const family = FAMILIES[input.family];
  const quantity = Math.max(0, Math.round(toNum(input.quantity)));
  const discountPct = clamp(round2(toNum(input.discountPct)), 0, 100);
  const result = {
    uid: input.uid,
    family: input.family,
    quantity,
    discountPct,
    lines: [],
    tierOptions: [],
    chosenTier: null,
    bestTier: null,
    annual: false,
    hint: '',
    hintLevel: 'info',
    error: '',
    timus: null,
  };
  if (!family) {
    result.error = `Unknown product family "${input.family}".`;
    return result;
  }
  if (input.family === 'timus') return priceTimus(input, setup, catalog, result);
  if (input.family === 'oneoff') return priceOneOff(input, catalog, result);

  const edition = effectiveEdition(input);
  const units = unitsFor(input.family, edition);
  const editionDef = family.editions.find((e) => e.value === edition);
  if (editionDef && editionDef.segments && !editionDef.segments.includes(setup.segment)) {
    result.error = `${family.label} ${editionDef.label.toLowerCase()} is ${editionDef.segments.join('/')} only. Change ${(family.pickerLabel || 'edition').toLowerCase()} to ${family.editions[0].label}.`;
    return result;
  }
  const key = catalogKey(input.family, edition, setup.segment, setup.billing);
  const tiersForKey = catalog.tiers[key];
  const billingLabel = (BILLING[setup.billing] || {}).label || setup.billing;
  if (!tiersForKey) {
    const ed = family.editions.length > 1 ? ` ${editionDef ? editionDef.label.toLowerCase() : edition}` : '';
    result.error = `No ${setup.segment} ${billingLabel.toLowerCase()} SKUs exist for ${family.label}${ed}. Change billing or edition.`;
    return result;
  }
  const annual = setup.billing === 'annual';
  result.annual = annual;
  const per = annual ? '/yr' : '/mo';

  const { options, best, cheapest } = tierOptionsFor(tiersForKey, quantity);
  if (!best) {
    result.error = `No base SKU found for ${family.label} (${key}).`;
    return result;
  }
  const requested = input.tier != null && input.tier !== '' ? toNum(input.tier, null) : null;
  const chosen = options.find((o) => o.tier === requested) || best;
  result.tierOptions = options.map((o) => ({
    value: String(o.tier),
    label: `${formatInt(o.tier)} ${units.unit} — ${formatMoney(o.cost)}${per}${o === cheapest && cheapest !== best ? ' (lowest price)' : ''}`,
    cost: o.cost,
  }));
  result.chosenTier = chosen.tier;
  const unpriced = missingPriceError([chosen.base, chosen.additional && chosen.addQty > 0 ? chosen.additional : null], catalog.currency || 'USD');
  if (unpriced) {
    result.error = unpriced;
    return result;
  }
  result.bestTier = best.tier;
  result.cheapestTier = cheapest.tier;

  result.lines.push(
    makeLine({
      family: input.family,
      kind: 'base',
      productId: chosen.base.id,
      name: chosen.base.name,
      sku: chosen.base.sku,
      quantity: chosen.baseQty,
      unitPrice: chosen.base.price,
      discountPct,
      annual,
    })
  );
  if (chosen.additional && chosen.addQty > 0) {
    result.lines.push(
      makeLine({
        family: input.family,
        kind: 'additional',
        productId: chosen.additional.id,
        name: chosen.additional.name,
        sku: chosen.additional.sku,
        quantity: chosen.addQty,
        unitPrice: chosen.additional.price,
        discountPct,
        annual,
      })
    );
  }

  if (quantity === 0) {
    result.error = input.coterm
      ? `The company has no ${units.unit} commit for ${family.label}, so it can't be co-termed yet. Ask Ops to fill it in on the company, then refresh the page.`
      : `Enter how many ${units.unit} to quote.`;
  } else if (chosen !== best && chosen.cost > cheapest.cost + 1e-9) {
    result.hint = `The ${formatInt(cheapest.tier)} tier covers ${formatInt(quantity)} ${units.unit} for ${formatMoney(cheapest.cost)}${per}, ${formatMoney(chosen.cost - cheapest.cost)}${per} less than the tier selected.`;
    result.hintLevel = 'warning';
  } else if (chosen.additional) {
    const extra = chosen.addQty > 0 ? ` + ${formatInt(chosen.addQty)} additional ${units.unit}` : '';
    const what = `${formatInt(chosen.tier)}-${units.unitSingular.toLowerCase()} commit${extra}`;
    if (chosen !== best) {
      result.hint = `${what} covers ${formatInt(quantity)} ${units.unit}, rounded up from the default ${formatInt(best.tier)} tier (${formatMoney(best.cost - chosen.cost)}${per} less).`;
    } else if (cheapest !== best) {
      result.hint = `${what} for ${formatInt(quantity)} ${units.unit}. The ${formatInt(cheapest.tier)} tier lists ${formatMoney(best.cost - cheapest.cost)}${per} less if you'd rather round up.`;
    } else {
      result.hint = `${what} for ${formatInt(quantity)} ${units.unit}.`;
    }
  } else {
    result.hint = `${formatInt(chosen.baseQty)} × ${formatInt(chosen.tier)}-${units.unitSingular.toLowerCase()} pack${chosen.baseQty > 1 ? 's' : ''} covers ${formatInt(quantity)} ${units.unit} at the lowest list price.`;
  }

  // Optimize TDR: an add-on to per-tenant Optimize365 on the same row. One line, volume priced.
  const tdrUsers = Math.max(0, Math.round(toNum(input.tdrUsers)));
  if (input.family === 'optimize365' && edition === OPTIMIZE_TDR.withEdition && tdrUsers > 0) {
    const tdrTiers = catalog.tiers[catalogKey('optimize365', OPTIMIZE_TDR.edition, setup.segment, setup.billing)] || {};
    const slot = Object.values(tdrTiers).find((t) => t.base);
    const product = slot && slot.base;
    const tier = tdrTier(tdrUsers);
    const cur = catalog.currency || 'USD';
    if (cur !== OPTIMIZE_TDR.currency) {
      result.error = result.error || `${OPTIMIZE_TDR.sku} tiers are only set in ${OPTIMIZE_TDR.currency}, so it can't be quoted in ${cur} yet. Set TDR users to 0, or ask Ops to add ${cur} tiers.`;
      return result;
    }
    if (!product) {
      result.error = result.error || `The ${OPTIMIZE_TDR.sku} product isn't available for ${setup.segment} ${billingLabel.toLowerCase()} (run Setup scripts → tag-products). Set TDR users to 0 to quote without it.`;
      return result;
    }
    result.tdrUsers = tdrUsers;
    result.lines.push(makeLine({ family: input.family, kind: 'tdr', productId: product.id, name: product.name, sku: product.sku, quantity: tdrUsers, unitPrice: tier.price, discountPct, annual }));
    const range = `${formatInt(tier.from)}${tier.to == null ? '+' : `–${formatInt(tier.to)}`}`;
    result.hint = `${result.hint} TDR: ${formatInt(tdrUsers)} users at ${formatMoney(tier.price)} (${range} tier).`.trim();
  }
  return result;
}

// Timus SASE: priced from the Timus SKUs in the product library. Standard agreements bill a
// "Monthly Minimum" line at the minimum the rep sets (the SKU price by default); satisfaction-guarantee
// agreements use a SATGAT SKU. The rep enters the per-user and per-gateway prices, which print on the
// quote through the deal properties Timus Price Per User / Timus Price Per Gateway.
const entered = (v) => v !== '' && v !== null && v !== undefined && Number.isFinite(Number(v));

// A one-off SKU: the product the rep picked, at its own price and billing frequency, × quantity.
const ONE_OFF_FREQUENCIES = { monthly: false, annually: true };
function priceOneOff(input, catalog, result) {
  const p = ((catalog && catalog.oneOffs) || []).find((o) => o.id === String(input.productId || ''));
  if (!input.productId) {
    result.error = 'Pick a one-off SKU.';
    return result;
  }
  if (!p) {
    result.error = `That one-off SKU is no longer active in the ${ONE_OFF_FOLDER} folder. Pick another.`;
    return result;
  }
  Object.assign(result, { baseFamily: p.baseFamily, baseEdition: p.baseEdition, productName: p.name });
  if (!(p.frequency in ONE_OFF_FREQUENCIES)) {
    result.error = `${p.name} has billing frequency "${p.frequency || 'none'}". One-off SKUs need Monthly or Annually (one-time charges aren't supported yet).`;
    return result;
  }
  if (!result.quantity) {
    result.error = 'Enter a quantity.';
    return result;
  }
  const unpriced = missingPriceError([p], catalog.currency || 'USD');
  if (unpriced) {
    result.error = unpriced;
    return result;
  }
  const annual = ONE_OFF_FREQUENCIES[p.frequency];
  result.annual = annual;
  result.lines.push(
    makeLine({ family: 'oneoff', kind: 'base', productId: p.id, name: p.name, sku: p.sku, quantity: result.quantity, unitPrice: p.price, discountPct: result.discountPct, annual })
  );
  result.hint = `${p.name}: ${formatMoney(p.price)}${annual ? '/yr' : '/mo'} each, from the product library.`;
  return result;
}

// The family a row counts as for product rules and wording: a one-off SKU counts as its product's family.
export function rowFamily(row) {
  return row.input.family === 'oneoff' ? row.priced.baseFamily || 'oneoff' : row.input.family;
}

// Products the company is already on (status Active), from its product status properties.
/** @param {Record<string, any> | null | undefined} companyProps @returns {string[]} */
export function activeProducts(companyProps) {
  const props = companyProps || {};
  return Object.keys(COMPANY_PRODUCT_STATUS).filter((f) => props[COMPANY_PRODUCT_STATUS[f].property] === COMPANY_PRODUCT_STATUS[f].active);
}

// The product a deal's pipeline sells (null for any other pipeline).
/** @param {string | null | undefined} pipelineId @returns {string | null} */
export function pipelineFamily(pipelineId) {
  return PIPELINE_FAMILY[String(pipelineId || '')] || null;
}

// False for a deal pipeline that never co-terms (Downgrade: the partner signs a new 12-month commit).
/** @param {string | number | null | undefined} pipelineId */
export function pipelineAllowsCoterm(pipelineId) {
  return !NO_COTERM_PIPELINES[String(pipelineId || '')];
}

// True for a Downgrade Pipeline deal: every line on it is tagged Downgrade.
/** @param {string | number | null | undefined} pipelineId */
export function isDowngradePipeline(pipelineId) {
  return !!DOWNGRADE_PIPELINES[String(pipelineId || '')];
}

// Active products the company pays Month-to-Month (its product Payment Terms on the company). Only these
// co-term; an Active product paid annually, quarterly, one time (or with no terms) is an Upsell.
/** @param {Record<string, any> | null | undefined} companyProps @returns {string[]} */
export function cotermProducts(companyProps) {
  const props = companyProps || {};
  return activeProducts(props).filter((f) => COTERM_COMMITS[f] && COTERM_PAYMENT_TERMS.includes(props[COTERM_COMMITS[f].paymentTerms]));
}

// Co-term is offered on a product the company is Active on and pays Month-to-Month (`active` = that list),
// other than the deal's own product (on an AutoElevate Upsell deal the AutoElevate line is the upsell itself).
/** @param {string} family @param {string[] | null | undefined} active @param {string | null} [dealFamily] */
export function canCoterm(family, active, dealFamily = null) {
  return Array.isArray(active) && active.includes(family) && family !== dealFamily;
}

// New / Upsell / Co-term for a row. A product the company is already Active on is an upsell, or a
// co-term for a co-term row where co-term is allowed (`cotermable`: Active and paid Month-to-Month;
// defaults to `active` for callers that don't know the terms); anything else is new. A co-term row on a
// product that can't co-term counts as an Upsell. `active` = null when the company is unknown.
/** @param {string} family @param {boolean} coterm @param {string[] | null | undefined} active @param {string | null} [dealFamily] @param {string[] | null | undefined} [cotermable] */
export function lineTypeFor(family, coterm, active, dealFamily = null, cotermable = active) {
  if (!(Array.isArray(active) && active.includes(family))) return LINE_TYPES.new;
  return coterm && canCoterm(family, cotermable, dealFamily) ? LINE_TYPES.coterm : LINE_TYPES.upsell;
}

// Company properties the automatic co-term reads (loaded with the deal's company).
/** @returns {string[]} */
export function cotermCompanyProperties() {
  const names = [];
  for (const src of Object.values(COTERM_COMMITS)) for (const [k, v] of Object.entries(src)) if (k !== 'edition' && !names.includes(v)) names.push(v);
  return names;
}

// The co-term rows a quote starts with: one per product the company is Active on, other than the deal's
// own product, that it pays Month-to-Month, sized from the company's commit.
// `company` = { activeProducts, cotermProducts, commits } from loadDeal.
// Rows carry `coterm: true` and a note saying where the numbers came from. No uid: the card adds it.
/** @param {any} company @param {{ dealFamily?: string | null, segment?: string, pipeline?: string | number | null }} [ctx] @returns {any[]} */
export function cotermRows(company, { dealFamily = null, segment = 'MSP', pipeline = null } = {}) {
  if (!company || !pipelineAllowsCoterm(pipeline)) return [];
  const c = company.commits || {};
  // Active and paid Month-to-Month (worked out from the commits when loadDeal didn't send the list).
  const active = company.cotermProducts || cotermProducts(Object.assign({}, c, Object.fromEntries((company.activeProducts || []).map((f) => [COMPANY_PRODUCT_STATUS[f].property, COMPANY_PRODUCT_STATUS[f].active]))));
  const count = (prop) => Math.max(0, Math.round(toNum(c[prop])));
  const label = (prop) => COTERM_PROPERTY_LABELS[prop] || prop;
  const shown = (prop) => (count(prop) ? formatInt(count(prop)) : 'blank');
  return FAMILY_ORDER.filter((f) => COTERM_COMMITS[f] && canCoterm(f, active, dealFamily)).map((family) => {
    const src = COTERM_COMMITS[family];
    const discount = cotermDiscount(c, src);
    const row = { family, coterm: true, edition: FAMILIES[family].editions[0].value, quantity: 0, tier: '', discountPct: discount.pct, ramp: false };
    if (family === 'autoelevate') {
      const companyType = c[src.featureType] || '';
      row.featureType = COTERM_AE_FEATURE[companyType] || 'Standard';
      row.edition = (AE_FEATURE_TYPES.find((f) => f.value === row.featureType) || AE_FEATURE_TYPES[0]).edition;
      row.quantity = count(src.quantity);
      row.cotermNote = `${label(src.quantity)} ${shown(src.quantity)} · ${label(src.featureType)} ${companyType || 'blank'} → ${row.featureType} SKUs`;
    } else if (family === 'timus') {
      const mrr = round2(toNum(c[src.minimum]));
      Object.assign(row, { agreement: 'standard', minimum: mrr > 0 ? mrr : '', satgatTier: '', gateways: 0, userRate: '', gatewayRate: '', quantity: count(src.users) });
      row.cotermNote = `${label(src.minimum)} ${mrr > 0 ? formatMoney(mrr) : 'blank'}`;
    } else if (family === 'optimize365') {
      const users = count(src.quantity);
      const tenants = count(src.tenants);
      // Per tenant when the company has a tenant commit (MSP only), else per user.
      const perTenant = tenants > 0 && segment === 'MSP';
      row.edition = perTenant ? 'tenant' : 'standard';
      row.quantity = perTenant ? tenants : users;
      row.tdrUsers = 0;
      row.cotermCounts = { users, tenants };
      row.cotermNote = perTenant ? `${label(src.tenants)} ${formatInt(tenants)}${users ? ` (${label(src.quantity)} ${formatInt(users)} not used)` : ''}` : `${label(src.quantity)} ${shown(src.quantity)}`;
    } else {
      if (src.edition) row.edition = src.edition;
      row.quantity = count(src.quantity);
      row.cotermNote = `${label(src.quantity)} ${shown(src.quantity)}`;
    }
    if (discount.from) row.cotermNote += ` · ${label(discount.from)} ${formatPct(discount.pct)}`;
    return row;
  });
}

const formatPct = (n) => `${Number.isInteger(n) ? n : n.toFixed(2).replace(/0$/, '')}%`;

// The discount a co-term starts at: the company's Current Discount, else its Initial Discount, else 0.
// HubSpot stores them as fractions (0.1 = 10%); a value above 1 is read as a percent already.
function cotermDiscount(c, src) {
  for (const prop of [src.currentDiscount, src.initialDiscount]) {
    const raw = c[prop];
    if (raw === null || raw === undefined || String(raw).trim() === '') continue;
    const n = toNum(raw, NaN);
    if (!Number.isFinite(n)) continue;
    return { pct: clamp(round2(n <= 1 ? n * 100 : n), 0, 100), from: prop };
  }
  return { pct: 0, from: null };
}

// Co-term rows come from the company record, so a saved or submitted co-term row is reset to the
// company's current values; only the rep's discount is kept. A co-term row for a product that can't
// co-term any more (not Active or not Month-to-Month) becomes a normal row. `seeds` = cotermRows().
/** @param {any[]} products @param {any[]} seeds @returns {any[]} */
export function refreshCoterms(products, seeds) {
  return (products || []).map((p) => {
    if (!p || !p.coterm) return p;
    const seed = (seeds || []).find((s) => s.family === p.family);
    if (!seed) return Object.assign({}, p, { coterm: false });
    return Object.assign({}, seed, { uid: p.uid, discountPct: p.discountPct });
  });
}

export function lineTypeLabel(value) {
  return LINE_TYPE_LABELS[value] || value || '';
}

// What to call a row on screen: the family, or a one-off's product name.
export function rowLabel(row) {
  if (row.input.family === 'oneoff') return row.priced.productName || FAMILIES.oneoff.label;
  return FAMILIES[row.input.family] ? FAMILIES[row.input.family].label : row.input.family;
}

function priceTimus(input, setup, catalog, result) {
  const gateways = Math.max(0, Math.round(toNum(input.gateways)));
  const userRate = round2(toNum(input.userRate));
  const gatewayRate = round2(toNum(input.gatewayRate));
  const satgatTiers = Object.keys(catalog.timus.satgat).map(Number).sort((a, b) => a - b);
  result.timus = { gateways, userRate, gatewayRate, minimum: 0, usage: 0, satgatTiers };

  const missing = [];
  if (!(userRate > 0)) missing.push('Timus Price Per User');
  if (!entered(input.gatewayRate) || gatewayRate < 0) missing.push('Timus Price Per Gateway');
  // A Timus co-term only re-signs the monthly minimum, so the rates are optional (they aren't written).
  result.timus.ratesEntered = missing.length === 0;
  if (missing.length && !input.coterm) {
    result.error = `Enter the ${missing.join(' and ')}. ${missing.length > 1 ? 'They print' : 'It prints'} on the quote.`;
    return result;
  }

  let minimum;
  if (input.agreement === 'satgat') {
    const tier = Number(input.satgatTier) || satgatTiers[0];
    const product = catalog.timus.satgat[tier];
    if (!product) {
      result.error = satgatTiers.length ? `Pick a SATGAT tier (${satgatTiers.map((t) => formatMoney(t, 0)).join(', ')}).` : 'No SATGAT SKUs are tagged for the Quote Builder.';
      return result;
    }
    minimum = tier;
    const unpriced = missingPriceError([product], catalog.currency || 'USD');
    if (unpriced) {
      result.error = unpriced;
      return result;
    }
    result.lines.push(
      makeLine({ family: 'timus', kind: 'satgat', productId: product.id, name: product.name, sku: product.sku, quantity: 1, unitPrice: product.price, discountPct: result.discountPct, annual: false })
    );
  } else {
    const product = catalog.timus.minimum;
    if (!product) {
      result.error = `The "${TIMUS.minimumSku}" product is not tagged for the Quote Builder.`;
      return result;
    }
    const repMinimum = entered(input.minimum) && toNum(input.minimum) > 0;
    if (input.coterm && !repMinimum) {
      result.error = "Timus Committed MRR is blank on the company, so Timus can't be co-termed yet. Ask Ops to fill it in, then refresh the page.";
      return result;
    }
    // The rep's minimum is in the deal's currency; the SKU's own price is only the default.
    if (!repMinimum && product.missingPrice) {
      result.error = `${missingPriceError([product], catalog.currency || 'USD')} Or enter the monthly minimum in ${catalog.currency}.`;
      return result;
    }
    minimum = repMinimum ? round2(toNum(input.minimum)) : product.price;
    result.lines.push(
      makeLine({
        family: 'timus',
        kind: 'minimum',
        productId: product.id,
        name: minimum === product.price ? product.name : `${product.name} - ${formatMoney(minimum, 0)}`,
        sku: product.sku,
        quantity: 1,
        unitPrice: minimum,
        discountPct: result.discountPct,
        annual: false,
      })
    );
  }
  const usage = round2(result.quantity * userRate + gateways * gatewayRate);
  Object.assign(result.timus, { minimum, usage });
  if (input.coterm && !result.timus.ratesEntered) {
    result.hint = `Co-term at a ${formatMoney(minimum)}/mo monthly minimum.`;
    return result;
  }

  if (setup.billing !== 'monthly') {
    result.hint = 'Timus SASE bills monthly against its minimum, whatever billing is set for the quote. ';
    result.hintLevel = 'warning';
  }
  if (usage <= minimum) {
    result.hint += `Estimated usage ${formatMoney(usage)}/mo is covered by the ${formatMoney(minimum, 0)} monthly minimum.`;
  } else {
    result.hint += `Estimated usage ${formatMoney(usage)}/mo is ${formatMoney(usage - minimum)} over the ${formatMoney(minimum, 0)} monthly minimum. Overage bills in the Timus portal; consider a higher minimum.`;
    result.hintLevel = 'warning';
  }
  return result;
}

// ---------------------------------------------------------------------------
// AutoElevate feature type (AE Feature Type + AE Feature Type Details on the deal)
// ---------------------------------------------------------------------------

export function aeFeatureTypeFor(input) {
  if (!input || input.family !== 'autoelevate') return null;
  const byValue = AE_FEATURE_TYPES.find((f) => f.value === input.featureType);
  if (byValue) return byValue;
  // No explicit choice: infer from the edition.
  return AE_FEATURE_TYPES.find((f) => f.edition === input.edition) || AE_FEATURE_TYPES[0];
}

// The SKU edition that prices a row. For AutoElevate the feature type decides it.
export function effectiveEdition(input) {
  const ft = aeFeatureTypeFor(input);
  return ft ? ft.edition : input.edition;
}

// The AE Feature Type a row implies: the rep's pick, or for a one-off AutoElevate SKU its edition.
function rowFeatureType(r) {
  if (r.input.family === 'oneoff') return AE_FEATURE_TYPES.find((f) => f.edition === r.priced.baseEdition) || AE_FEATURE_TYPES[0];
  return aeFeatureTypeFor(r.input);
}

export function resolveAeFeature(rows) {
  const aeRows = (rows || []).filter((r) => r.input.family === 'autoelevate' || (r.input.family === 'oneoff' && r.priced.baseFamily === 'autoelevate'));
  if (!aeRows.length) return null;
  const types = Array.from(new Set(aeRows.map((r) => rowFeatureType(r).value)));
  if (types.length > 1) {
    return {
      conflict: `AutoElevate lines use different feature types (${types.join(', ')}). The deal holds one AE Feature Type, so the quote can only print one. Use one feature type, or split into separate quotes.`,
    };
  }
  const ft = rowFeatureType(aeRows[0]);
  const priced = aeRows.find((r) => r.usable) || aeRows[0];
  const tier = priced.priced.chosenTier;
  return { type: ft.value, details: ft.details.replace('{tier}', tier ? formatInt(tier) : '[commit tier]'), tier };
}

// ---------------------------------------------------------------------------
// Whole quote
// ---------------------------------------------------------------------------

// A ramp is one or more stages run back to back, e.g. [{2 months free}, {2 months 50% off}].
// Older saved quotes stored a single { months, mode, percent }; they read as one stage.
export function normalizeStage(st) {
  const mode = st && st.mode === 'percent' ? 'percent' : 'free';
  return {
    months: clamp(Math.round(toNum(st && st.months, 1)), 1, MAX_RAMP_MONTHS),
    mode,
    percent: mode === 'percent' ? clamp(Math.round(toNum(st.percent, 50)), 1, 99) : 100,
  };
}

export function rampStages(ramp) {
  const raw = ramp && Array.isArray(ramp.stages) && ramp.stages.length ? ramp.stages : [ramp || {}];
  return raw.slice(0, MAX_RAMP_STAGES).map(normalizeStage);
}

export function normalizeRamp(ramp) {
  const enabled = !!(ramp && ramp.enabled);
  const stages = enabled ? rampStages(ramp) : [];
  let start = 1;
  for (const st of stages) {
    st.startMonth = start;
    start += st.months;
  }
  return { enabled, stages, months: stages.reduce((a, st) => a + st.months, 0) };
}

// Default ramp length when Ramp is first ticked: whatever the agreement runs past 12 months
// (16 months → 4, 18 → 6), capped at the maximum; agreements of 12 months or less get a short ramp.
export function defaultRampMonths(agreementLength) {
  const m = agreementMonths(agreementLength);
  if (!m) return 3;
  if (m > 12) return Math.min(MAX_RAMP_MONTHS, m - 12);
  return Math.max(1, Math.min(3, m - 1));
}

// "Free", "50% off"
export const stageLabel = (st) => (st.mode === 'free' ? 'Free' : `${st.percent}% off`);

// "15 Months" → 15; the Month-to-Month option → null.
export function agreementMonths(value) {
  if (!value || value === AGREEMENT_LENGTH_M2M) return null;
  const m = String(value).match(/^(\d+)\s*Months?$/i);
  return m ? Number(m[1]) : null;
}

// SKU billing actually used: a Month-to-Month Agreement Length means month-to-month SKUs.
export function effectiveBilling(setup) {
  if (setup.agreementLength === AGREEMENT_LENGTH_M2M) return 'm2m';
  return setup.billing === 'annual' ? 'annual' : 'monthly';
}

// Can Optimize365 ramp on this Setup, and for how long? { allowed, months, reason }.
export function optimizeRampRule(setup) {
  const billing = effectiveBilling(setup || {});
  const frequency = (setup && setup.paymentFrequency) || PAYMENT_FREQUENCY_DEFAULT[billing];
  const okMonths = Array.from({ length: OPTIMIZE_RAMP.maxMonths }, (_, i) => i + 1);
  const orList = (xs) => (xs.length > 1 ? `${xs.slice(0, -1).join(', ')} or ${xs[xs.length - 1]}` : String(xs[0]));
  const lengths = orList(okMonths.map((m) => OPTIMIZE_RAMP.planMonths + m));
  if (billing === 'm2m') return { allowed: false, months: 0, reason: 'Month-to-month Optimize365 quotes can\'t ramp.' };
  if (billing === 'annual' || frequency === 'Annual Payments') return { allowed: false, months: 0, reason: 'Optimize365 paid annually upfront can\'t ramp.' };
  const extra = (agreementMonths(setup.agreementLength) || 0) - OPTIMIZE_RAMP.planMonths;
  if (extra < 1 || extra > OPTIMIZE_RAMP.maxMonths) {
    return { allowed: false, months: 0, reason: `Optimize365 can only ramp on a ${lengths}-month agreement paid monthly (${orList(okMonths)} free months on top of ${OPTIMIZE_RAMP.planMonths}).` };
  }
  return { allowed: true, months: extra, reason: `Optimize365 ramp: ${extra} free month${extra > 1 ? 's' : ''} on top of the 12-month plan.` };
}

// A product's own ramp. Each product with Ramp ticked carries its stages (input.rampStages), so AutoElevate
// can be 2 months free while DNS Filtering is 2 months at 50% off. Quotes saved before per-product ramps
// kept one shared ramp; `fallback` (that shared ramp) is used for any ticked product without its own stages.
export function productRamp(input, fallback) {
  if (!input || !input.ramp) return normalizeRamp(null);
  const own = Array.isArray(input.rampStages) && input.rampStages.length ? { stages: input.rampStages } : null;
  return normalizeRamp(Object.assign({}, own || fallback || {}, { enabled: true }));
}

// The rep picks the Agreement Length (what prints on the quote). It includes any ramp:
// each ramped product runs RAMP lines for its own ramp months, then its plan for the rest;
// products not on a ramp run the plan for the whole agreement.
export function buildQuote(setup, inputs, rampInput, catalog) {
  const legacyRamp = rampInput && (Array.isArray(rampInput.stages) ? rampInput.stages.length : rampInput.months) ? rampInput : null;
  const billing = effectiveBilling(setup);
  const priceSetup = Object.assign({}, setup, { billing });
  const m2m = billing === 'm2m';
  const months = m2m ? null : agreementMonths(setup.agreementLength);
  const agreement = months || 12;
  const conflicts = [];
  if (!m2m && !months) conflicts.push('Pick an Agreement Length on the Setup step.');
  const optimizeRamp = optimizeRampRule(setup);

  const rows = (inputs || []).map((input) => {
    const priced = priceProduct(input, priceSetup, catalog);
    const usable = !priced.error && priced.lines.length > 0;
    const ramp = productRamp(input, legacyRamp);
    // Co-term rows re-sign an existing product at its commit: no ramp.
    const ramped = ramp.enabled && usable && !input.coterm;
    const label = rowLabel({ input, priced });
    if (ramped && ramp.months > MAX_RAMP_MONTHS) {
      conflicts.push(`${label}: the ramp stages add up to ${ramp.months} months; the most is ${MAX_RAMP_MONTHS}.`);
    }
    if (ramped && !m2m && ramp.months >= agreement) {
      conflicts.push(`${label}: the ${ramp.months}-month ramp is as long as the ${agreement}-month Agreement Length. Pick a longer Agreement Length or a shorter ramp.`);
    }
    // Optimize365 ramps only as free months on top of 12 (13 → 1, 14 → 2), billed monthly.
    if (ramped && rowFamily({ input, priced }) === OPTIMIZE_RAMP.family) {
      if (!optimizeRamp.allowed) conflicts.push(`${optimizeRamp.reason} Untick Ramp on Optimize365, or change the Agreement Length / payment on Setup.`);
      else if (ramp.stages.length > 1 || ramp.stages[0].mode !== 'free' || ramp.months !== optimizeRamp.months) {
        conflicts.push(`Optimize365's ramp must be ${optimizeRamp.months} free month${optimizeRamp.months > 1 ? 's' : ''} (one stage, 100% off) on this ${agreement}-month agreement.`);
      }
    }
    const rampMonths = ramped ? ramp.months : 0;
    const multiStage = ramp.stages.length > 1;
    // NetSuite auto-split fields, written on every line of the row.
    const family = rowFamily({ input, priced });
    const cotermable = setup.cotermProducts !== undefined ? setup.cotermProducts : setup.activeProducts;
    const cotermAllowed = canCoterm(family, cotermable, setup.dealFamily);
    // Every line on a Downgrade Pipeline deal is Downgrade; otherwise New / Upsell / Co-term.
    const lineType = setup.downgrade ? LINE_TYPES.downgrade : lineTypeFor(family, !!input.coterm, setup.activeProducts, setup.dealFamily, cotermable);
    const tag = { qbFamily: family, lineType };
    const mainTerm = m2m ? 1 : Math.max(1, agreement - rampMonths);
    const valueMonths = m2m ? 12 : mainTerm; // months used to value an open-ended M2M quote
    const mainLines = priced.lines.map((l) => Object.assign({}, l, tag, { ramp: false, termMonths: mainTerm, startMonth: rampMonths + 1 }));
    // One RAMP line per product line per stage: "RAMP …" for a single stage, "RAMP 1 …", "RAMP 2 …" for steps.
    const rampLines = ramped
      ? ramp.stages.flatMap((st, si) =>
          priced.lines.map((l) =>
            Object.assign(makeLine(Object.assign({}, l, tag, { discountPct: st.mode === 'free' ? 100 : st.percent })), {
              name: (multiStage ? `${RAMP_NAME_PREFIX.trim()} ${si + 1} ` : RAMP_NAME_PREFIX) + l.name,
              ramp: true,
              stage: si + 1,
              termMonths: st.months,
              startMonth: st.startMonth,
              rampTotal: ramp.months, // this product's whole ramp, for approval_ramp_months
            })
          )
        )
      : [];
    const sum = (ls, k) => ls.reduce((a, l) => a + l[k], 0);
    return {
      input,
      family,
      lineType,
      cotermAllowed, // the card shows the Co-term box only on products the company is Active on
      label,
      priced,
      usable,
      ramped,
      ramp,
      rampMonths,
      mainTerm,
      valueMonths,
      mainLines,
      rampLines,
      mainMrr: sum(mainLines, 'mrr'),
      rampMrr: sum(rampLines.filter((l) => l.stage === 1), 'mrr'),
      // Per-stage monthly amount for this product (the billing schedule uses one value per stage).
      stageMrr: ramp.stages.map((st, si) => sum(rampLines.filter((l) => l.stage === si + 1), 'mrr')),
      rampValue: rampLines.reduce((a, l) => a + l.mrr * l.termMonths, 0),
      listMrr: sum(mainLines, 'listMrr'),
    };
  });

  const lines = [];
  for (const r of rows) {
    if (!r.usable) continue;
    for (const l of r.rampLines) lines.push(l);
    for (const l of r.mainLines) lines.push(l);
  }
  lines.forEach((l, i) => (l.position = i + 1));

  const anyRamp = rows.some((r) => r.ramped);
  const longestRamp = rows.reduce((a, r) => Math.max(a, r.rampMonths), 0);
  let mrr = 0;
  let firstYear = 0;
  let tcv = 0;
  let listTcv = 0;
  let maxDiscountPct = 0;
  let maxDiscountFamily = null;
  for (const r of rows) {
    if (!r.usable) continue;
    const rm = r.rampMonths;
    mrr += r.mainMrr;
    if (r.ramped) {
      r.ramp.stages.forEach((st, si) => {
        firstYear += Math.max(0, Math.min(12, st.startMonth - 1 + st.months) - (st.startMonth - 1)) * r.stageMrr[si];
      });
    }
    firstYear += Math.max(0, 12 - rm) * r.mainMrr;
    tcv += r.rampValue + r.valueMonths * r.mainMrr;
    listTcv += (rm + r.valueMonths) * r.listMrr;
    if (r.priced.discountPct > maxDiscountPct) {
      maxDiscountPct = r.priced.discountPct;
      maxDiscountFamily = r.family;
    }
  }

  const totals = {
    mrr: round2(mrr),
    arr: round2(mrr * 12),
    firstYear: round2(firstYear),
    tcv: round2(tcv),
    listTcv: round2(listTcv),
    savings: round2(Math.max(0, listTcv - tcv)),
    contractMonths: m2m ? null : agreement,
    maxDiscountPct,
    maxDiscountFamily,
  };

  // Approval looks at the longest ramp on the quote (each RAMP line also carries its own product's total).
  const approval = evaluateApproval({
    maxDiscountPct,
    maxDiscountFamily,
    rampMonths: longestRamp,
    salesTeam: setup.salesTeam,
    templateType: setup.templateType,
  });

  const blocking = rows.filter((r) => !r.usable).map((r) => ({ uid: r.input.uid, family: r.input.family, error: r.priced.error }));
  const aeFeature = resolveAeFeature(rows);
  if (aeFeature && aeFeature.conflict) conflicts.push(aeFeature.conflict);

  // `ramp` summarises the quote: on when any product ramps; `months` is the longest product ramp.
  const ramp = { enabled: anyRamp, months: longestRamp };
  return { segment: setup.segment, ramp, term: agreement, billing, m2m, rows, lines, totals, approval, blocking, conflicts, aeFeature, anyRamp, optimizeRamp, oneOffs: (catalog && catalog.oneOffs) || [], currency: (catalog && catalog.currency) || QUOTE_DEFAULTS.currency };
}

export function evaluateApproval({ maxDiscountPct, maxDiscountFamily, rampMonths, salesTeam, templateType }) {
  const reasons = [];
  if (maxDiscountPct >= APPROVAL.discountThresholdPct) {
    const label = maxDiscountFamily && FAMILIES[maxDiscountFamily] ? FAMILIES[maxDiscountFamily].label : 'a product';
    reasons.push(`${maxDiscountPct}% discount on ${label} (${APPROVAL.discountThresholdPct}% or more needs approval)`);
  }
  if (rampMonths >= APPROVAL.rampMonthsThreshold) {
    reasons.push(`${rampMonths}-month ramp (${APPROVAL.rampMonthsThreshold}+ months needs approval)`);
  }
  const approver = APPROVAL.approversByTeam[salesTeam] || APPROVAL.fallbackApprover;
  const legacy = templateType && templateType !== 'CPQ_QUOTE';
  return {
    required: reasons.length > 0,
    reasons,
    approver,
    // Commerce Hub approval workflows only run on CPQ quotes.
    manual: legacy && reasons.length > 0,
  };
}

// ---------------------------------------------------------------------------
// HubSpot property mapping
// ---------------------------------------------------------------------------

export function lineItemProperties(line, { billing, rampMonths, sessionId, currency }) {
  const props = {
    hs_line_item_currency_code: quoteCurrency(currency),
    hs_product_id: line.productId,
    name: line.name,
    hs_sku: line.sku,
    quantity: String(line.quantity),
    price: String(line.unitPrice),
    hs_discount_percentage: String(line.discountPct),
    recurringbillingfrequency: line.annual ? 'annually' : 'monthly',
    hs_position_on_quote: String(line.position),
    ramp: line.ramp ? 'true' : 'false',
    approval_discount: String(line.ramp ? 0 : line.discountPct),
    // This product's total ramp length (all stages), so the approval rule sees a 2 + 2 ramp as 4 months.
    approval_ramp_months: String(line.ramp ? line.rampTotal || rampMonths || line.termMonths : 0),
    [LINE_SOURCE_PROPERTY]: LINE_SOURCE_VALUE,
    [LINE_SESSION_PROPERTY]: sessionId,
  };
  // NetSuite auto-split: which product the line belongs to and whether it's New, Upsell or Co-term.
  if (line.qbFamily) props[LINE_FAMILY_PROPERTY] = line.qbFamily;
  if (line.lineType) props[LINE_TYPE_PROPERTY] = line.lineType;
  if (billing === 'm2m' && !line.ramp) {
    props.hs_recurring_billing_terms = 'AUTOMATICALLY_RENEW';
  } else {
    props.hs_recurring_billing_period = `P${line.termMonths}M`;
  }
  if (SET_BILLING_DELAY_AFTER_RAMP && line.startMonth > 1) {
    props.hs_billing_start_delay_type = 'hs_billing_start_delay_months';
    props.hs_billing_start_delay_months = String(line.startMonth - 1);
  }
  return props;
}

// Deal properties the quote template prints as tokens, plus bookkeeping fields.
// `enumOptions` = { propertyName: [{ value, label }] } read live from HubSpot; a value that
// isn't an option is reported as an error instead of being written.
// HubSpot Quote Notes (hubspot_quote_notes) holds special verbiage reps write themselves, so the
// builder never writes it.
/** @param {any} quote @param {{ setup?: any }} [ctx] @param {Record<string, {value: string, label: string}[]>} [enumOptions] */
export function dealWrites(quote, { setup = {} } = {}, enumOptions = {}) {
  const properties = {};
  const errors = [];
  const warnings = [];
  const options = (name) => (enumOptions && enumOptions[name]) || [];
  const accepts = (name, value) => !options(name).length || options(name).some((o) => o.value === value);
  const labelOf = (name, value) => (options(name).find((o) => o.value === value) || { label: value }).label;
  const setEnum = (name, label, value) => {
    if (value === '' || value == null) {
      properties[name] = '';
      return;
    }
    if (accepts(name, value)) properties[name] = value;
    else errors.push(`${label} has no "${value}" option in HubSpot. Add the option to the deal property or pick another value.`);
  };

  const agreementLength = setup.agreementLength || '';
  if (!agreementLength) errors.push('Pick an Agreement Length on the Setup step.');
  else setEnum('agreement_length', 'Agreement Length', agreementLength);
  if (WRITE_CONTRACT_TERM) properties.contract_term = quote.m2m ? '' : String(quote.totals.contractMonths);

  const billing = effectiveBilling(setup);
  const paymentFrequency = setup.paymentFrequency || PAYMENT_FREQUENCY_DEFAULT[billing] || 'Month-to-Month';
  setEnum('payment_terms', 'Payment Frequency', paymentFrequency);
  if (billing === 'annual' && paymentFrequency !== 'Annual Payments') {
    warnings.push(`The SKUs are annual but Payment Frequency is ${labelOf('payment_terms', paymentFrequency)}.`);
  }
  setEnum('payment_method', 'Payment Method', setup.paymentMethod || '');
  setEnum('invoice_terms', 'Invoice Terms', setup.invoiceTerms || '');

  if (quote.aeFeature && !quote.aeFeature.conflict) {
    setEnum('sku_type', 'AE Feature Type', quote.aeFeature.type);
    properties.ae_feature_type_details = quote.aeFeature.details;
  }

  // A Timus co-term (on another product's deal) leaves the Timus deal fields alone.
  const timusRow = quote.rows.find((r) => r.input.family === 'timus' && r.usable && r.lineType !== LINE_TYPES.coterm);
  if (timusRow && timusRow.priced.timus) {
    // Timus Price List is being retired, so the builder leaves it untouched.
    const t = timusRow.priced.timus;
    Object.assign(properties, {
      timus_price_per_user: t.userRate.toFixed(2),
      timus_price_per_gateway: t.gatewayRate.toFixed(2),
      new_minimum_commitment_amount: String(t.minimum),
    });
  }
  return { properties, errors, warnings, agreementLength, paymentFrequency };
}

// ---------------------------------------------------------------------------
// Multiple quotes (options) on one deal
// ---------------------------------------------------------------------------

// 'open' quotes still read the deal's current printed values; 'locked' ones were frozen at publish.
// Can the builder edit this quote in place? { editable, reason }
export function quoteEditability(q) {
  if (!q || !q.builder || !q.state) return { editable: false, reason: 'Not made with the Quote Builder.' };
  const status = q.progressionStatus || 'DRAFT';
  if (QUOTE_EDITABLE_STATUSES.includes(status)) return { editable: true, reason: '' };
  if (status === 'PENDING_APPROVAL') return { editable: false, reason: 'Recall the approval request in HubSpot to edit it.' };
  return { editable: false, reason: 'Published quotes are locked. Start a new option from it instead.' };
}

// Where "Open quote" should go. CPQ quotes open in HubSpot's quote editor (it also shows published
// quotes read-only). Legacy quotes: drafts open in the old edit wizard, the rest on the details page.
// (/quotes/{portal}/details/{id} only works for published legacy quotes; for a CPQ quote it lands on an
// empty "All quotes" list.)
export function quoteUrl(portalId, quoteId, templateType, progressionStatus) {
  if (templateType === 'CPQ_QUOTE') return `https://app.hubspot.com/quote/${portalId}/editor/${quoteId}/content`;
  const draft = !progressionStatus || progressionStatus === 'DRAFT';
  return `https://app.hubspot.com/quotes/${portalId}/${draft ? 'edit' : 'details'}/${quoteId}`;
}

export function quoteLockState(progressionStatus) {
  const s = progressionStatus || 'DRAFT';
  if (QUOTE_IGNORED_STATUSES.includes(s)) return 'void';
  return QUOTE_OPEN_STATUSES.includes(s) ? 'open' : 'locked';
}

// Open quotes whose printed values would change if `newProps` were written to the deal.
export function openQuoteConflicts(quotes, currentDealProps, newProps) {
  const changed = PRINTED_DEAL_PROPERTIES.filter(
    (k) => k in (newProps || {}) && String((currentDealProps || {})[k] || '') !== String(newProps[k] || '')
  );
  if (!changed.length) return { changed, quotes: [] };
  return { changed, quotes: (quotes || []).filter((q) => quoteLockState(q.progressionStatus) === 'open') };
}

// What a builder quote stores so it can be cloned or made primary later.
export function builderState({ setup, products, ramp }, dealProperties) {
  return JSON.stringify({ v: 1, setup, products, ramp, dealProperties });
}

export function parseBuilderState(value) {
  try {
    const s = JSON.parse(value || '');
    return s && s.v === 1 ? s : null;
  } catch (_) {
    return null;
  }
}

export function autoQuoteName(companyName, inputs, rampMonths, catalog) {
  const seen = [];
  for (const i of inputs || []) {
    // A one-off SKU is named by its product's family (AutoElevate, Optimize365 …) when known.
    const one = i.family === 'oneoff' && catalog && (catalog.oneOffs || []).find((o) => o.id === String(i.productId || ''));
    const fam = i.family === 'oneoff' ? (one && one.baseFamily) || 'oneoff' : i.family;
    const label = FAMILIES[fam] ? FAMILIES[fam].label : null;
    if (label && !seen.includes(label)) seen.push(label);
  }
  const base = `${companyName || 'Quote'} - ${seen.join(' + ') || 'Quote'}`;
  return rampMonths ? `${base} + ${rampMonths} Month Ramp` : base;
}

// Server-side guard: reject anything the card should never send.
export function validateSubmission(payload) {
  const errors = [];
  const { setup = {}, products = [], ramp = {} } = payload || {};
  if (!['MSP', 'ENT'].includes(setup.segment)) errors.push('segment must be MSP or ENT');
  if (!BILLING[setup.billing]) errors.push('billing must be monthly, annual or m2m');
  if (!setup.agreementLength || typeof setup.agreementLength !== 'string') errors.push('agreementLength is required');
  else if (setup.agreementLength !== AGREEMENT_LENGTH_M2M && !agreementMonths(setup.agreementLength)) errors.push('agreementLength must look like "15 Months"');
  if (!setup.templateId) errors.push('templateId is required');
  if (!setup.expirationDate || !/^\d{4}-\d{2}-\d{2}$/.test(setup.expirationDate)) errors.push('expirationDate must be YYYY-MM-DD');
  if (!Array.isArray(products) || products.length === 0) errors.push('at least one product is required');
  if (products.length > 12) errors.push('at most 12 product rows');
  for (const p of products) {
    if (!FAMILIES[p.family]) errors.push(`unknown family ${p.family}`);
    const d = toNum(p.discountPct, NaN);
    if (!(d >= 0 && d <= 100)) errors.push(`discount for ${p.family} must be 0–100`);
    const q = toNum(p.quantity, NaN);
    if (!(q >= 0 && q <= 1000000)) errors.push(`quantity for ${p.family} is out of range`);
    if (p.family === 'autoelevate' && p.featureType && !AE_FEATURE_TYPES.some((f) => f.value === p.featureType)) errors.push(`unknown AE feature type ${p.featureType}`);
    const tdr = toNum(p.tdrUsers, 0);
    if (!(tdr >= 0 && tdr <= 1000000)) errors.push(`TDR users for ${p.family} is out of range`);
    if (p.family === 'oneoff' && p.productId != null && typeof p.productId !== 'string' && typeof p.productId !== 'number') errors.push('one-off productId must be an id');
    if (p.coterm != null && typeof p.coterm !== 'boolean') errors.push(`coterm for ${p.family} must be true or false`);
  }
  const checkStages = (raw, who) => {
    if (raw.length > MAX_RAMP_STAGES) errors.push(`${who}: at most ${MAX_RAMP_STAGES} ramp stages`);
    let total = 0;
    for (const st of raw) {
      const m = toNum(st && st.months, NaN);
      if (!(m >= 1 && m <= MAX_RAMP_MONTHS)) errors.push(`${who}: ramp stage months must be 1–${MAX_RAMP_MONTHS}`);
      if (st && st.mode === 'percent' && !(toNum(st.percent, NaN) >= 1 && toNum(st.percent, NaN) <= 99)) errors.push(`${who}: ramp stage percent must be 1–99`);
      total += m || 0;
    }
    if (total > MAX_RAMP_MONTHS) errors.push(`${who}: ramp stages add up to ${total} months; the most is ${MAX_RAMP_MONTHS}`);
  };
  for (const p of products) {
    if (p.ramp && Array.isArray(p.rampStages) && p.rampStages.length) checkStages(p.rampStages, p.family);
  }
  // Older cards sent one shared ramp.
  if (ramp.enabled && (Array.isArray(ramp.stages) ? ramp.stages.length : ramp.months)) checkStages(Array.isArray(ramp.stages) ? ramp.stages : [ramp], 'ramp');
  return errors;
}
