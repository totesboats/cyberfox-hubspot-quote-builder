import React, { useCallback, useEffect, useMemo, useReducer, useState } from 'react';
import {
  hubspot,
  Alert,
  Button,
  ErrorState,
  Flex,
  LoadingSpinner,
  StepIndicator,
  Text,
  useExtensionActions,
  useExtensionContext,
} from '@hubspot/ui-extensions';
import { SetupStep } from './components/SetupStep.jsx';
import { ProductsStep } from './components/ProductsStep.jsx';
import { ReviewStep } from './components/ReviewStep.jsx';
import { SummaryPanel } from './components/SummaryPanel.jsx';
import { QuotesPanel } from './components/QuotesPanel.jsx';
import { buildQuote, cotermRows, dealWrites, isDowngradePipeline, pipelineAllowsCoterm, refreshCoterms, defaultRampMonths, indexCatalog, openQuoteConflicts, optimizeRampRule, pipelineFamily, quoteCurrency, rampStages, suggestTemplate } from './lib/pricing.js';
import { AE_FEATURE_TYPES, AGREEMENT_LENGTH_DEFAULT, FAMILIES, INVOICE_TERMS_DEFAULT, MAX_RAMP_STAGES, QUOTE_DEFAULTS } from './lib/config.js';

export const STEPS = ['Setup', 'Products & ramp', 'Review & create'];

// hubspot.serverless resolves to the function's return value; older runtimes wrap it.
export async function callFunction(name, parameters) {
  const res = await hubspot.serverless(name, { parameters });
  if (res && res.status === 'ERROR') throw new Error(res.message || `${name} failed`);
  const body = res && res.status && res.response !== undefined ? res.response : res;
  if (!body) throw new Error(`${name} returned nothing`);
  return body;
}

function isoInDays(days) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

export const initialState = {
  step: 0,
  setup: {
    templateId: '',
    segment: 'MSP',
    billing: 'monthly',
    agreementLength: AGREEMENT_LENGTH_DEFAULT,
    expirationDate: isoInDays(QUOTE_DEFAULTS.expirationDays),
    paymentFrequency: '', // '' = follow billing
    paymentMethod: 'Credit Card',
    invoiceTerms: INVOICE_TERMS_DEFAULT,
    acceptance: 'esignature',
    signerContactId: '',
    quoteName: '',
  },
  products: [],
  nextUid: 1,
  primary: null, // null = automatic: primary when it's the deal's first builder quote
  editing: null, // { id, title, primary } while editing an existing builder quote in place
};

// Each product carries its own ramp (product.rampStages). `ramp` in the payload only says whether
// any product ramps; quotes saved before per-product ramps kept one shared ramp (see withOwnRamps).
export function rampFor(state) {
  return { enabled: state.products.some((p) => p.ramp) };
}

// The ramp a product starts with when Ramp is ticked: the months the agreement runs past 12, free
// (16 months → 4). Optimize365 starts at its only allowed shape (13 months → 1 free, 14 → 2, 15 → 3).
export function defaultProductStages(setup, family) {
  const optimize = family === 'optimize365' ? optimizeRampRule(setup) : null;
  const months = optimize && optimize.allowed ? optimize.months : defaultRampMonths(setup.agreementLength);
  return [{ months, mode: 'free', percent: 50 }];
}

// AE Feature Types reps can pick; a retired one (e.g. Advanced (GrandFathered)) or a blank starts as Standard.
export function offeredFeatureType(value) {
  return AE_FEATURE_TYPES.some((f) => f.value === value) ? value : 'Standard';
}

// Saved quotes: give each ticked product its own copy of an older shared ramp, and move retired
// AE Feature Types to Standard.
function withOwnRamps(products, savedRamp) {
  return products.map((p) => {
    const next = p.ramp && !(Array.isArray(p.rampStages) && p.rampStages.length) ? Object.assign({}, p, { rampStages: rampStages(savedRamp) }) : Object.assign({}, p);
    if (next.family === 'autoelevate') next.featureType = offeredFeatureType(next.featureType);
    return next;
  });
}

// Automatic co-term: add a Co-term row for each product the company is Active on (and pays Month-to-Month)
// that the quote doesn't have yet (a one-off SKU counts as its product). `coterms` come from cotermRows()
// at load. Saved co-term rows are reset to the company record (keeping the rep's discount); one on a product
// that can no longer co-term becomes a normal row.
export function withCoterms(products, coterms, nextUid) {
  const list = coterms || [];
  const kept = refreshCoterms(products, list);
  const have = new Set(kept.map((p) => (p.family === 'oneoff' ? p.baseFamily : p.family)));
  const add = list.filter((c) => !have.has(c.family)).map((c, i) => Object.assign({}, c, { uid: nextUid + i }));
  return { products: kept.concat(add), nextUid: nextUid + add.length };
}

const mapStages = (state, uid, fn) =>
  Object.assign({}, state, { products: state.products.map((p) => (p.uid === uid && p.ramp ? Object.assign({}, p, { rampStages: fn(p.rampStages || []) }) : p)) });

/** @param {typeof initialState} state @param {any} action @returns {typeof initialState} */
export function reducer(state, action) {
  switch (action.type) {
    case 'hydrate': {
      const next = Object.assign({}, state, { setup: Object.assign({}, state.setup, action.setup) });
      // A fresh quote starts with the company's co-term rows.
      if (state.products.length || state.editing) return next;
      return Object.assign(next, withCoterms([], action.coterms, state.nextUid));
    }
    case 'step':
      return Object.assign({}, state, { step: Math.max(0, Math.min(STEPS.length - 1, action.step)) });
    case 'setup': {
      const setup = Object.assign({}, state.setup, action.patch);
      if (action.patch.segment && action.patch.segment !== state.setup.segment) {
        // An edition the new segment doesn't sell (Optimize365 per tenant on Enterprise) goes back to the first one.
        const products = state.products.map((p) => {
          const fam = FAMILIES[p.family];
          const ed = fam && fam.editions.find((e) => e.value === p.edition);
          if (!(ed && ed.segments && !ed.segments.includes(setup.segment))) return p;
          const reset = { edition: fam.editions[0].value, tier: '' };
          // A per-tenant Optimize co-term falls back to the company's user commit.
          if (p.coterm && p.cotermCounts) reset.quantity = p.cotermCounts.users || 0;
          return Object.assign({}, p, reset);
        });
        state = Object.assign({}, state, { products });
      }
      if (!action.patch.agreementLength) return Object.assign({}, state, { setup });
      // Agreement Length changed: a product ramp still at its default single stage follows the new default.
      const products = state.products.map((p) => {
        const st = p.rampStages || [];
        if (!p.ramp || st.length !== 1 || st[0].months !== defaultProductStages(state.setup, p.family === 'oneoff' ? p.baseFamily : p.family)[0].months) return p;
        return Object.assign({}, p, { rampStages: [Object.assign({}, st[0], { months: defaultProductStages(setup, p.family === 'oneoff' ? p.baseFamily : p.family)[0].months })] });
      });
      return Object.assign({}, state, { setup, products });
    }
    case 'addProduct': {
      const family = FAMILIES[action.family];
      const row = {
        uid: state.nextUid,
        family: action.family,
        edition: family.editions[0].value,
        quantity: action.family === 'timus' ? 50 : 100,
        tier: '',
        discountPct: 0,
        ramp: false,
      };
      if (action.family === 'autoelevate') row.featureType = offeredFeatureType(action.defaultAeFeatureType);
      if (action.family === 'oneoff') Object.assign(row, { quantity: 1, productId: '', baseFamily: null });
      // Optimize365 starts per user; MSP reps can switch to per tenant (with the optional TDR add-on).
      if (action.family === 'optimize365') row.tdrUsers = 0;
      if (action.family === 'timus') {
        // Rates start from the deal's current values (if any) so an existing Timus deal re-quotes as-is.
        const t = action.timusDefaults || {};
        Object.assign(row, { agreement: 'standard', minimum: '', satgatTier: '', gateways: 1, userRate: t.userRate ?? '', gatewayRate: t.gatewayRate ?? '' });
      }
      return Object.assign({}, state, { products: state.products.concat([row]), nextUid: state.nextUid + 1 });
    }
    case 'updateProduct': {
      const products = state.products.map((p) => {
        if (p.uid !== action.uid) return p;
        const next = Object.assign({}, p, action.patch);
        // Ticking Ramp gives the product its own ramp at the default; unticking drops it.
        if (action.patch.ramp === true && !p.ramp) next.rampStages = defaultProductStages(state.setup, p.family === 'oneoff' ? p.baseFamily : p.family);
        if (action.patch.ramp === false) delete next.rampStages;
        return next;
      });
      return Object.assign({}, state, { products });
    }
    case 'removeProduct':
      // Co-term rows stay: every product the company is Active on is co-termed.
      return Object.assign({}, state, { products: state.products.filter((p) => p.uid !== action.uid || p.coterm) });
    case 'clearRamp':
      return Object.assign({}, state, {
        products: state.products.map((p) => {
          if (!p.ramp) return p;
          const next = Object.assign({}, p, { ramp: false });
          delete next.rampStages;
          return next;
        }),
      });
    case 'rampStage':
      return mapStages(state, action.uid, (stages) => stages.map((st, i) => (i === action.index ? Object.assign({}, st, action.patch) : st)));
    case 'addRampStage':
      return mapStages(state, action.uid, (stages) => {
        if (stages.length >= MAX_RAMP_STAGES) return stages;
        /** @type {any} */
        const last = stages[stages.length - 1] || { months: 1, mode: 'free', percent: 100 };
        // Next step down: half the previous discount (free → 50% off).
        const prev = last.mode === 'percent' ? Number(last.percent) || 50 : 100;
        return stages.concat([{ months: 1, mode: 'percent', percent: Math.max(1, Math.round(prev / 2)) }]);
      });
    case 'removeRampStage':
      return mapStages(state, action.uid, (stages) => (stages.length > 1 ? stages.filter((_, i) => i !== action.index) : stages));
    case 'primary':
      return Object.assign({}, state, { primary: action.value });
    case 'loadState': {
      // Start a new option from a saved builder quote: same inputs, fresh dates, not primary.
      const saved = action.state;
      const own = withOwnRamps((saved.products || []).map((p, i) => Object.assign({}, p, { uid: i + 1 })), saved.ramp);
      const { products, nextUid } = withCoterms(own, action.coterms, own.length + 1);
      return Object.assign({}, state, {
        step: 1,
        setup: Object.assign({}, state.setup, saved.setup, { expirationDate: state.setup.expirationDate, quoteName: '' }),
        products,
        nextUid,
        primary: false,
        editing: null,
      });
    }
    case 'editQuote': {
      // Edit an existing builder quote in place: its saved inputs, its own name and expiry.
      const q = action.quote;
      const saved = q.state || {};
      const own = withOwnRamps((saved.products || []).map((p, i) => Object.assign({}, p, { uid: i + 1 })), saved.ramp);
      const { products, nextUid } = withCoterms(own, action.coterms, own.length + 1);
      return Object.assign({}, state, {
        step: 0,
        setup: Object.assign({}, state.setup, saved.setup, { quoteName: q.title || '', expirationDate: q.expirationDate || (saved.setup && saved.setup.expirationDate) || state.setup.expirationDate }),
        products,
        nextUid,
        primary: !!q.primary,
        editing: { id: q.id, title: q.title, primary: !!q.primary },
      });
    }
    case 'stopEditing':
      return Object.assign({}, initialState, { setup: state.setup, editing: null }, withCoterms([], action.coterms, 1));
    case 'nextOption':
      return Object.assign({}, state, { step: 1, primary: false, editing: null, setup: Object.assign({}, state.setup, { quoteName: '' }) });
    default:
      return state;
  }
}

export function QuoteBuilderApp() {
  /** @type {any} */
  const context = useExtensionContext();
  /** @type {any} */
  const actions = useExtensionActions();
  const dealId = context && context.crm ? String(context.crm.objectId) : '';

  const [data, setData] = useState(null);
  const [loadError, setLoadError] = useState('');
  /** @type {[typeof initialState, (action: any) => void]} */
  const [state, dispatch] = useReducer(reducer, initialState);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState(null);
  const [busyQuoteId, setBusyQuoteId] = useState('');
  const [pendingPrimary, setPendingPrimary] = useState('');

  // refresh = reload after a write; keeps whatever the rep has entered.
  const load = useCallback(async (refresh = false) => {
    setLoadError('');
    try {
      const res = await callFunction('quote_builder_catalog', { dealId });
      if (!res.ok) throw new Error((res.errors || []).join('; ') || 'Could not load the product library.');
      // Priced in the deal's currency: a CAD deal uses each product's CAD price.
      const catalog = indexCatalog(res.products, quoteCurrency(res.deal && res.deal.properties && res.deal.properties.deal_currency_code));
      const props = (res.deal && res.deal.properties) || {};
      const segment = res.deal && res.deal.salesTeam === 'ENT' ? 'ENT' : 'MSP';
      // Co-term rows for every product the company is Active on, sized from its commits.
      const coterms = cotermRows(res.deal && res.deal.company, { dealFamily: pipelineFamily(props.pipeline), segment, pipeline: props.pipeline });
      setData(Object.assign({}, res, { catalog, coterms }));
      if (refresh === true) return;
      dispatch({
        type: 'hydrate',
        coterms,
        setup: {
          segment,
          paymentMethod: props.payment_method || 'Credit Card',
          invoiceTerms: INVOICE_TERMS_DEFAULT, // always starts here, even if the deal holds Net-30 etc.
          signerContactId: res.deal && res.deal.contacts[0] ? res.deal.contacts[0].id : '',
          paymentFrequency: props.payment_terms || '',
          agreementLength: props.agreement_length || AGREEMENT_LENGTH_DEFAULT,
        },
      });
    } catch (err) {
      setLoadError(err.message);
    }
  }, [dealId]);

  useEffect(() => {
    if (dealId) load();
  }, [dealId, load]);

  // One-off SKUs count as their product's family (AutoElevate, Optimize365 …) for the template suggestion.
  const families = state.products.map((p) => (p.family === 'oneoff' ? p.baseFamily || 'oneoff' : p.family));
  const suggested = useMemo(() => (data ? suggestTemplate(data.templates, families) : null), [data, families.join(',')]);
  const template = data ? data.templates.find((t) => t.id === state.setup.templateId) || suggested : null;

  const quote = useMemo(() => {
    if (!data) return null;
    const setup = Object.assign({}, state.setup, {
      salesTeam: data.deal.salesTeam,
      templateType: template ? template.templateType : 'CPQ_QUOTE',
      activeProducts: data.deal.company ? data.deal.company.activeProducts || null : null,
      // undefined for an older catalog response (then any Active product can co-term)
      // none on a Downgrade deal (new 12-month commit)
      cotermProducts: !pipelineAllowsCoterm(data.deal.properties && data.deal.properties.pipeline) ? [] : data.deal.company ? data.deal.company.cotermProducts : null,
      dealFamily: pipelineFamily(data.deal.properties && data.deal.properties.pipeline),
      downgrade: isDowngradePipeline(data.deal.properties && data.deal.properties.pipeline),
    });
    return buildQuote(setup, state.products, rampFor(state), data.catalog);
  }, [data, state.setup, state.products, template]);
  // Deal properties the quote template prints as tokens (validated against live options).
  const writes = useMemo(() => (quote ? dealWrites(quote, { setup: state.setup }, data.dealOptions) : null), [quote, state.setup, data]);

  if (loadError) {
    return (
      <ErrorState title="The Quote Builder couldn't load">
        <Text>{loadError}</Text>
        <Button onClick={() => load()}>Try again</Button>
      </ErrorState>
    );
  }
  if (!data || !quote) return <LoadingSpinner label="Loading the product library…" showLabel layout="centered" />;

  const quotes = data.deal.quotes || [];
  const primary = state.primary == null ? !quotes.some((q) => q.builder) : state.primary;
  const affected = openQuoteConflicts(quotes.filter((q) => !state.editing || q.id !== state.editing.id), data.deal.properties, writes.properties).quotes;

  const makePrimary = async (quoteId) => {
    setPendingPrimary('');
    setBusyQuoteId(quoteId);
    try {
      const res = await callFunction('quote_builder_set_primary', { dealId, quoteId });
      if (!res.ok) throw new Error((res.errors || []).join(' '));
      actions.addAlert({ type: 'success', title: 'Primary option updated', message: `The deal now carries this quote's ${res.lineCount || 0} line items and printed fields.` });
      if (actions.refreshObjectProperties) actions.refreshObjectProperties();
      await load(true);
    } catch (err) {
      actions.addAlert({ type: 'danger', title: "Couldn't change the primary option", message: err.message });
    } finally {
      setBusyQuoteId('');
    }
  };
  const requestPrimary = (q) => {
    const others = quotes.filter((x) => x.id !== q.id);
    const risky = openQuoteConflicts(others, data.deal.properties, (q.state && q.state.dealProperties) || {}).quotes;
    if (risky.length) setPendingPrimary(q.id);
    else makePrimary(q.id);
  };

  const blocker =
    state.step === 0 && !state.setup.agreementLength
      ? 'Pick an Agreement Length.'
      : state.step === 1 && state.products.length === 0
      ? 'Add at least one product.'
      : state.step === 1 && quote.blocking.length
        ? 'Fix the highlighted product before continuing.'
        : state.step === 1 && quote.conflicts.length
          ? 'Fix the issue above before continuing.'
        : state.step === 2 && quote.conflicts.length
          ? quote.conflicts[0]
        : state.step === 2 && writes.errors.length
          ? 'Fix the deal property issues below.'
        : state.step === 2 && !template
          ? 'Pick a quote template on the Setup step.'
          : state.step === 2 && quote.lines.length === 0
            ? 'There are no line items to write.'
            : '';

  const submit = async () => {
    setSubmitting(true);
    setResult(null);
    try {
      const payload = {
        dealId,
        setup: Object.assign({}, state.setup, { templateId: template.id }),
        products: state.products,
        ramp: rampFor(state),
        primary,
        editQuoteId: state.editing ? state.editing.id : undefined,
        // The quote's seller is whoever builds it (HubSpot only lets the sender request approval).
        builder: { email: context && context.user ? context.user.email : '' },
      };
      const res = await callFunction('quote_builder_submit', payload);
      setResult(res);
      if (res.ok) {
        actions.addAlert({
          type: 'success',
          title: res.edited ? 'Quote updated' : 'Quote created',
          message: res.edited ? `${res.title} now has ${res.lineCount} line items.` : `${res.title} was created as a draft with ${res.lineCount} line items.`,
        });
        if (actions.refreshObjectProperties) actions.refreshObjectProperties();
        load(true); // refresh the quotes list
      } else {
        actions.addAlert({ type: 'danger', title: state.editing ? 'Quote not updated' : 'Quote not created', message: (res.errors || []).join(' ') });
      }
    } catch (err) {
      setResult({ ok: false, errors: [err.message] });
      actions.addAlert({ type: 'danger', title: state.editing ? 'Quote not updated' : 'Quote not created', message: err.message });
    } finally {
      setSubmitting(false);
    }
  };

  const go = (step) => dispatch({ type: 'step', step });
  const isLast = state.step === STEPS.length - 1;
  const created = !!(result && result.ok);

  return (
    <Flex direction="column" gap="medium">
      {data.issues && data.issues.length > 0 && (
        <Alert title="Product library needs attention" variant="warning">
          {data.issues.slice(0, 5).join(' · ')}
          {data.issues.length > 5 ? ` · and ${data.issues.length - 5} more` : ''}
        </Alert>
      )}

      {state.editing && (
        <Alert title={`Editing ${state.editing.title || 'quote'}`} variant="info">
          <Flex justify="between" align="center" gap="medium">
            <Text>Update quote replaces this quote's line items and settings. It keeps the same quote and link{state.editing.primary ? ', and it stays the primary option' : ''}.</Text>
            <Button
              size="sm"
              variant="secondary"
              onClick={() => {
                setResult(null);
                dispatch({ type: 'stopEditing', coterms: data.coterms });
              }}
            >
              Stop editing
            </Button>
          </Flex>
        </Alert>
      )}

      {state.step === 0 && (
        <QuotesPanel
          quotes={quotes}
          portalId={data.portalId || (context && context.portal ? context.portal.id : '')}
          busyId={busyQuoteId}
          pendingPrimary={pendingPrimary}
          onStartFrom={(q) => {
            setResult(null);
            dispatch({ type: 'loadState', state: q.state, coterms: data.coterms });
          }}
          editingId={state.editing ? state.editing.id : ''}
          onEdit={(q) => {
            setResult(null);
            dispatch({ type: 'editQuote', quote: q, coterms: data.coterms });
          }}
          onMakePrimary={requestPrimary}
          onConfirmPrimary={() => makePrimary(pendingPrimary)}
          onCancelPrimary={() => setPendingPrimary('')}
        />
      )}

      <StepIndicator stepNames={STEPS} currentStep={state.step} onClick={go} />

      {/* Totals and approval status follow the rep through every step, right under the step tracker. */}
      <SummaryPanel quote={quote} template={template} dealQuoteCount={data.deal.quoteCount} />

      {state.step === 0 && (
        <SetupStep
          setup={state.setup}
          templates={data.templates}
          suggested={suggested}
          contacts={data.deal.contacts}
          owner={data.deal.owner}
          user={context && context.user}
          dealOptions={data.dealOptions}
          onChange={(patch) => dispatch({ type: 'setup', patch })}
        />
      )}
      {state.step === 1 && (
        <ProductsStep
          quote={quote}
          setup={state.setup}
          writes={writes}
          dealOptions={data.dealOptions}
          onEditSetup={() => go(0)}
          onAdd={(family) =>
            dispatch({
              type: 'addProduct',
              family,
              timusDefaults: {
                userRate: data.deal.properties.timus_price_per_user || '',
                gatewayRate: data.deal.properties.timus_price_per_gateway || '',
              },
              defaultAeFeatureType: data.deal.properties.sku_type || '',
            })
          }
          onUpdate={(uid, patch) => dispatch({ type: 'updateProduct', uid, patch })}
          onRemove={(uid) => dispatch({ type: 'removeProduct', uid })}
          ramp={rampFor(state)}
          onStage={(uid, index, patch) => dispatch({ type: 'rampStage', uid, index, patch })}
          onAddStage={(uid) => dispatch({ type: 'addRampStage', uid })}
          onRemoveStage={(uid, index) => dispatch({ type: 'removeRampStage', uid, index })}
          onClearRamp={() => dispatch({ type: 'clearRamp' })}
        />
      )}
      {state.step === 2 && (
        <ReviewStep
          quote={quote}
          setup={state.setup}
          template={template}
          deal={data.deal}
          products={state.products}
          primary={primary}
          editing={state.editing}
          firstBuilderQuote={!quotes.some((q) => q.builder)}
          onPrimary={(value) => dispatch({ type: 'primary', value })}
          affectedQuotes={affected}
          onAnotherOption={() => {
            setResult(null);
            dispatch({ type: 'nextOption' });
          }}
          result={result}
          onReloadPage={actions && actions.reloadPage ? () => actions.reloadPage() : undefined}
          writes={writes}
          dealOptions={data.dealOptions}
        />
      )}

      {blocker && (
        <Flex justify="end">
          <Text variant="microcopy">{blocker}</Text>
        </Flex>
      )}
      <Flex justify="end" align="center" gap="small">
        {state.step > 0 && (
          <Button variant="secondary" disabled={submitting} onClick={() => go(state.step - 1)}>
            Back
          </Button>
        )}
        {isLast ? (
          <Button variant="primary" disabled={!!blocker || submitting || created} onClick={submit}>
            {state.editing ? (submitting ? 'Updating quote…' : created ? 'Quote updated' : 'Update quote') : submitting ? 'Creating quote…' : created ? 'Quote created' : 'Create quote'}
          </Button>
        ) : (
          <Button variant="primary" disabled={!!blocker} onClick={() => go(state.step + 1)}>
            Continue
          </Button>
        )}
      </Flex>
    </Flex>
  );
}
